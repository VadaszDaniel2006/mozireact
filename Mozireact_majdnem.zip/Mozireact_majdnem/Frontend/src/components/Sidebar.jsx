import React from 'react';
import '../App.css'; 

const Sidebar = ({ isOpen, onClose, title, items, onItemClick, onDeleteItem }) => {
  return (
    <>
      <div className={`sidebar-overlay ${isOpen ? 'open' : ''}`} onClick={onClose}></div>
      
      <div className={`sidebar ${isOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
            <h3>{title}</h3>
            <button className="close-sidebar-btn" onClick={onClose}>
                <i className="fas fa-times"></i>
            </button>
        </div>
        
        <div className="sidebar-content">
            {items.length === 0 ? (
                <p className="empty-msg">A lista jelenleg üres.</p>
            ) : (
                items.map((item) => {
                    const displayTitle = item.film_cim || item.sorozat_cim;
                    const displayPoster = item.film_poster || item.sorozat_poster;
                    const type = item.film_id ? "Film" : "Sorozat";

                    return (
                        <div key={item.id} className="sidebar-item">
                            {/* Tartalomra kattintva megnyitás */}
                            <div className="sidebar-item-clickable" onClick={() => onItemClick(item)}>
                                <img src={displayPoster} alt={displayTitle} />
                                <div className="sidebar-item-info">
                                    <h4>{displayTitle}</h4>
                                    <span className="item-type">{type}</span>
                                    <span className="item-date">{new Date(item.added_at).toLocaleDateString()}</span>
                                </div>
                            </div>

                            {/* Törlés gomb */}
                            <button 
                                className="sidebar-delete-btn"
                                onClick={(e) => { e.stopPropagation(); onDeleteItem(item.id); }}
                                title="Eltávolítás"
                            >
                                <i className="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    );
                })
            )}
        </div>
      </div>
    </>
  );
};

export default Sidebar;