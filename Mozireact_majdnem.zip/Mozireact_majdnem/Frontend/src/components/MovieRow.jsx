import React from 'react';
import MovieCard from './MovieCard';

// 1. A paraméterek közé felvettem az 'onOpenStreaming'-et
const MovieRow = ({ title, items, user, onOpenInfo, onOpenTrailer, onOpenStreaming, onAddToFav, onAddToList }) => {
  if (!items || items.length === 0) return null;

  return (
    <div className="row-wrapper">
      <h2 className="row-header">{title}</h2>
      <div className="movies-grid">
        {items.map((item) => (
          <MovieCard 
            key={item.id} 
            movie={item} 
            user={user} 
            onOpenInfo={onOpenInfo}
            onOpenTrailer={onOpenTrailer}
            onOpenStreaming={onOpenStreaming} // 2. Itt továbbadjuk a kártyának
            onAddToFav={onAddToFav}
            onAddToList={onAddToList}
          />
        ))}
      </div>
    </div>
  );
};

export default MovieRow;