import React, { useState, useRef, useEffect } from 'react';

export default function ProfilDropdown({ user, onLogout, onOpenProfile }) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Kattintás kívülre (bezárja a menüt)
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="profil-container" ref={dropdownRef}>
      
      {/* 1. GOMB (Avatar + Név + Nyíl) */}
      <div className="profil-btn" onClick={() => setIsOpen(!isOpen)}>
        <div className="profil-avatar-small">
          <img 
            src={user?.avatar || 'https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png'} 
            alt={user?.username || 'User'} 
          />
        </div>
        <span className="profil-name">
            {user?.name || user?.username || 'Felhasználó'}
        </span>
        <i className={`fas fa-chevron-${isOpen ? 'up' : 'down'}`}></i>
      </div>

      {/* 2. LENYÍLÓ MENÜ */}
      {isOpen && (
        <div className="profil-menu">
          
          {/* Fejléc */}
          <div className="profil-header">
            <div className="profil-avatar-large">
               <img 
                 src={user?.avatar || 'https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png'} 
                 alt={user?.username} 
               />
            </div>
            <div className="profil-info">
                <h4>{user?.name}</h4>
                <p>@{user?.username}</p>
                {/* Kedvenc kategóriák (max 2 db megjelenítése) */}
                {user?.favoriteCategories && (
                    <div className="profil-tags">
                        {user.favoriteCategories.slice(0, 2).map((cat, i) => (
                            <span key={i} className="profil-tag">{cat}</span>
                        ))}
                        {user.favoriteCategories.length > 2 && (
                            <span className="profil-tag">+{user.favoriteCategories.length - 2}</span>
                        )}
                    </div>
                )}
            </div>
          </div>

          {/* Menüpontok */}
          <div className="profil-menu-items">
            
            {/* --- ITT A LÉNYEG: PROFIL SZERKESZTÉSE --- */}
            {/* Nem nyitunk itt modalt, csak jelezzük a Navbarnak/Appnak, hogy nyissa meg */}
            <button 
                className="menu-item" 
                onClick={() => {
                    setIsOpen(false); // Bezárjuk a lenyíló menüt
                    if (onOpenProfile) onOpenProfile(); // Megnyitjuk a nagy modalt
                }}
            >
                <i className="fas fa-edit"></i> Profil szerkesztése
            </button>
            
            <button className="menu-item">
                <i className="fas fa-heart"></i> Kedvenceim
            </button>

            <button className="menu-item">
                <i className="fas fa-list"></i> Saját listáim
            </button>

            <div className="menu-divider"></div>

            <button className="menu-item logout" onClick={onLogout}>
                <i className="fas fa-sign-out-alt"></i> Kijelentkezés
            </button>
          </div>
        </div>
      )}
    </div>
  );
}