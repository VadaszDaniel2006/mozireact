// src/routes/interactionRoutes.js
const express = require('express');
const router = express.Router();
const interactionController = require('../controllers/interactionController');

// Kedvenc hozzáadása
router.post('/favorite', interactionController.addToFavorites);

// Kedvencek lekérése (Sidebarhoz)
router.get('/users/:userId/favorites', interactionController.getFavorites);

module.exports = router;