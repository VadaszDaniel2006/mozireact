const db = require('../config/db');

// --- 1. KEDVENCEK (kedvencek tábla) ---

exports.addToFavorites = async (req, res) => {
    const { userId, filmId, sorozatId } = req.body;
    try {
        // Ellenőrzés
        const [existing] = await db.query(
            'SELECT id FROM kedvencek WHERE user_id = ? AND (film_id = ? OR sorozat_id = ?)',
            [userId, filmId || null, sorozatId || null]
        );
        if (existing.length > 0) return res.status(400).json({ message: "Már a kedvencek között van!" });

        // Mentés
        await db.query('INSERT INTO kedvencek (user_id, film_id, sorozat_id, added_at) VALUES (?, ?, ?, NOW())', [userId, filmId || null, sorozatId || null]);
        res.status(201).json({ message: "Hozzáadva a kedvencekhez!" });
    } catch (error) { res.status(500).json({ message: "Hiba történt." }); }
};

exports.getFavorites = async (req, res) => {
    const userId = req.params.userId;
    try {
        const sql = `
            SELECT k.id, k.added_at, 'fav' as origin,
                   f.id as film_id, f.cim as film_cim, f.poszter_url as film_poster,
                   s.id as sorozat_id, s.cim as sorozat_cim, s.poszter_url as sorozat_poster
            FROM kedvencek k
            LEFT JOIN filmek f ON k.film_id = f.id
            LEFT JOIN sorozatok s ON k.sorozat_id = s.id
            WHERE k.user_id = ? ORDER BY k.added_at DESC`;
        const [favorites] = await db.query(sql, [userId]);
        res.json(favorites);
    } catch (err) { res.status(500).json({ message: "Hiba a lekéréskor" }); }
};

// Kedvenc TÖRLÉSE
exports.removeFromFavorites = async (req, res) => {
    const { userId, itemId } = req.body; // itemId: a sor ID-ja a kedvencek táblában
    try {
        await db.query('DELETE FROM kedvencek WHERE id = ? AND user_id = ?', [itemId, userId]);
        res.json({ message: "Törölve a kedvencekből." });
    } catch (err) { res.status(500).json({ message: "Hiba törléskor." }); }
};


// --- 2. SAJÁT LISTA (custom_lists és custom_list_items táblák) ---

exports.addToMyList = async (req, res) => {
    const { userId, filmId, sorozatId } = req.body;
    
    try {
        // 1. Megkeressük a felhasználó alapértelmezett listáját ("Saját listám")
        let [lists] = await db.query('SELECT id FROM custom_lists WHERE user_id = ? LIMIT 1', [userId]);
        
        let listId;
        if (lists.length === 0) {
            // Ha valamiért nincs listája, létrehozunk egyet gyorsan
            const [newList] = await db.query("INSERT INTO custom_lists (user_id, title, created_at) VALUES (?, 'Saját listám', NOW())", [userId]);
            listId = newList.insertId;
        } else {
            listId = lists[0].id;
        }

        // 2. Ellenőrizzük, hogy a film benne van-e már ebben a listában (custom_list_items)
        const [existingItem] = await db.query(
            'SELECT id FROM custom_list_items WHERE list_id = ? AND (film_id = ? OR sorozat_id = ?)',
            [listId, filmId || null, sorozatId || null]
        );

        if (existingItem.length > 0) return res.status(400).json({ message: "Már a listádon van!" });

        // 3. Mentés a tételek közé
        await db.query(
            'INSERT INTO custom_list_items (list_id, film_id, sorozat_id, added_at) VALUES (?, ?, ?, NOW())', 
            [listId, filmId || null, sorozatId || null]
        );

        res.status(201).json({ message: "Hozzáadva a listához!" });

    } catch (error) { 
        console.error(error);
        res.status(500).json({ message: "Hiba történt a mentéskor." }); 
    }
};

exports.getMyList = async (req, res) => {
    const userId = req.params.userId;
    try {
        // Összetett lekérdezés: custom_list -> custom_list_items -> filmek/sorozatok
        const sql = `
            SELECT cli.id, cli.added_at, 'list' as origin,
                   f.id as film_id, f.cim as film_cim, f.poszter_url as film_poster,
                   s.id as sorozat_id, s.cim as sorozat_cim, s.poszter_url as sorozat_poster
            FROM custom_lists cl
            JOIN custom_list_items cli ON cl.id = cli.list_id
            LEFT JOIN filmek f ON cli.film_id = f.id
            LEFT JOIN sorozatok s ON cli.sorozat_id = s.id
            WHERE cl.user_id = ? 
            ORDER BY cli.added_at DESC`;
            
        const [list] = await db.query(sql, [userId]);
        res.json(list);
    } catch (err) { 
        console.error(err);
        res.status(500).json({ message: "Hiba a lekéréskor" }); 
    }
};

// Tétel TÖRLÉSE a Saját listából
exports.removeFromMyList = async (req, res) => {
    const { userId, itemId } = req.body; // itemId: a sor ID-ja a custom_list_items táblában
    try {
        // Biztonsági ellenőrzés: csak akkor töröljük, ha a lista a useré
        const sql = `
            DELETE cli FROM custom_list_items cli
            JOIN custom_lists cl ON cli.list_id = cl.id
            WHERE cli.id = ? AND cl.user_id = ?
        `;
        await db.query(sql, [itemId, userId]);
        res.json({ message: "Törölve a listából." });
    } catch (err) { res.status(500).json({ message: "Hiba törléskor." }); }
};