import React from 'react';

const MovieCard = ({ 
  movie, 
  user, 
  onOpenInfo, 
  onOpenTrailer, 
  onOpenStreaming, 
  onAddToFav, 
  onAddToList, 
  onOpenReviews 
}) => {
  if (!movie) return null;

  return (
    <div className="movie-card-container">
      {/* 1. KÉP KATTINTÁS -> TRAILER */}
      <div 
        className="movie-card" 
        onClick={() => onOpenTrailer && onOpenTrailer(movie.elozetes_url, movie.cim)}
      >
        <div className="card-image">
          <img src={movie.poszter_url || movie.poster} alt={movie.cim} />
          <div className="card-overlay">
            <i className="fas fa-play-circle"></i>
          </div>
        </div>

        {/* Gombok konténere */}
        <div className="user-interactions" onClick={(e) => e.stopPropagation()}>
            
            {/* Vélemény gomb - MINDIG látható */}
            <button 
                className="btn-icon reviews" 
                onClick={(e) => { 
                    e.stopPropagation(); 
                    if (onOpenReviews) onOpenReviews(movie); 
                }} 
                title="Vélemények"
                style={{ marginRight: '5px' }}
            >
                <i className="fas fa-comment-alt"></i>
            </button>

            {/* Kedvencek és Lista - CSAK ha be van lépve */}
            {user && (
                <>
                    <button 
                        className="btn-fav" 
                        onClick={(e) => { e.stopPropagation(); onAddToFav(movie); }} 
                        title="Kedvencek"
                    >
                        <i className="fas fa-heart"></i>
                    </button>
                    <button 
                        className="btn-add-list" 
                        onClick={(e) => { e.stopPropagation(); onAddToList(movie); }} 
                        title="Saját lista"
                    >
                        <i className="fas fa-plus"></i>
                    </button>
                </>
            )}
        </div>
      </div>

      <div className="card-details">
        <h4>{movie.cim || movie.title}</h4>
        <div className="card-meta">
          <span>{movie.megjelenes_ev || movie.year}</span>
          <span><i className="fas fa-star"></i> {movie.rating}</span>
        </div>
      </div>

      <div className="card-buttons">
        <button 
            className="btn-card-play" 
            onClick={(e) => { 
                e.stopPropagation(); 
                if (onOpenStreaming) onOpenStreaming(movie); 
            }}
        >
          <i className="fas fa-play"></i> Megnézem
        </button>
        
        <button 
            className="btn-card-info" 
            onClick={(e) => { 
                e.stopPropagation(); 
                if (onOpenInfo) onOpenInfo(movie); 
            }}
        >
          <i className="fas fa-info-circle"></i> Részletek
        </button>
      </div>
    </div>
  );
};

export default MovieCard;