export default function MovieRow({ title, items, onOpenTrailer, onOpenInfo, isSeries = false }) {
  return (
    <section className="more-movies-section">
      <h2>{title}</h2>
      <div className="movies-grid">
        {items.map((item, index) => (
          <div key={index} className={`movie-card ${isSeries ? 'series-card' : ''}`}>
            
            <div className="card-image">
              <img src={item.poster} alt={item.title} />
              
              {/* Ha ez sorozat, csak badge van, ha film, akkor lejátszás gomb */}
              {isSeries ? (
                  <div className="series-badge">Sorozat</div>
              ) : (
                  <div className="card-overlay">
                    <button 
                        className="card-play-btn" 
                        onClick={(e) => {
                            e.stopPropagation(); // Ez fontos, hogy ne nyissa meg az infót is egyszerre
                            onOpenTrailer(item.trailerId, item.title);
                        }}
                    >
                      <i className="fas fa-play"></i>
                    </button>
                  </div>
              )}
            </div>

            {/* A kártya szöveges részére kattintva nyílik az Infó */}
            <div 
                className="card-content" 
                onClick={() => onOpenInfo(item)} 
                style={{cursor: 'pointer'}}
            >
              <h4>{item.title}</h4>
              <p>{item.year}</p>
            </div>

          </div>
        ))}
      </div>
    </section>
  );
}