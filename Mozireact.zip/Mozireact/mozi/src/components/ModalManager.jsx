import { platformsInfo } from '../data';

export default function ModalManager({ 
  trailerModal, closeTrailer, 
  infoModal, closeInfo, openStreaming,
  streamingModal, closeStreaming 
}) {
  return (
    <>
      {/* Trailer Modal */}
      {trailerModal.isOpen && (
        <div className="modal active" onClick={closeTrailer}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{trailerModal.title}</h3>
              <button className="close-modal" onClick={closeTrailer}><i className="fas fa-times"></i></button>
            </div>
            <div className="video-container">
              <iframe 
                width="100%" height="315" 
                src={`https://www.youtube.com/embed/${trailerModal.videoId}?autoplay=1`} 
                title="Trailer" frameBorder="0" allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      )}

      {/* Info Modal */}
      {infoModal.isOpen && infoModal.movie && (
        <div className="modal active" onClick={closeInfo}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Részletek</h3>
              <button className="close-modal" onClick={closeInfo}><i className="fas fa-times"></i></button>
            </div>
            <div className="info-content" style={{display:'flex', gap:'20px'}}>
              <img src={infoModal.movie.poster} alt="" style={{width:'150px', borderRadius:'8px'}} />
              <div>
                <h4>{infoModal.movie.title}</h4>
                <p>{infoModal.movie.description}</p>
                <p><strong>Rendező:</strong> {infoModal.movie.director}</p>
                <p><strong>Szereplők:</strong> {infoModal.movie.actors}</p>
                <button className="btn-primary" onClick={() => openStreaming(infoModal.movie)}>
                  Megnézem most
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Streaming Modal */}
      {streamingModal.isOpen && streamingModal.movie && (
        <div className="modal active" onClick={closeStreaming}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Hol nézheted meg?</h3>
              <button className="close-modal" onClick={closeStreaming}><i className="fas fa-times"></i></button>
            </div>
            <div className="streaming-services">
              {streamingModal.movie.platforms && streamingModal.movie.platforms.map(platform => (
                <div key={platform} className="streaming-service" onClick={() => window.open(platformsInfo[platform].url, '_blank')} style={{cursor:'pointer', padding:'10px', display:'flex', alignItems:'center', gap:'10px'}}>
                   <img src={platformsInfo[platform].logo} alt={platformsInfo[platform].name} style={{width:'40px'}}/>
                   <span>{platformsInfo[platform].name}</span>
                </div>
              ))}
              {(!streamingModal.movie.platforms) && <p>Nincs elérhető streaming adat.</p>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}