import { useState, useEffect } from 'react';
import logo from '../logo.png'; // Ellenőrizd, hogy ez a fájlneved!

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Görgetés figyelése: ha lejjebb görgetsz, sötétebb lesz a navbar
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <nav style={{ 
          // Görgetéskor besötétedik, amúgy kicsit áttetszőbb
          backgroundColor: scrolled ? 'rgba(11, 15, 43, 0.98)' : 'rgba(11, 15, 43, 0.9)', 
          transition: 'background-color 0.3s ease' 
      }}>
        <div className="nav-container">
            
            {/* LOGÓ - A CSS mix-blend-mode intézi a hátteret */}
            <div className="logo" onClick={() => window.scrollTo(0,0)}>
                <img src={logo} alt="MoziPont Logo" />
            </div>

            {/* JOBB OLDALI MENÜ */}
            <div className="nav-right">
                
                {/* Asztali menüpontok (A CSS mobilon elrejti a span-okat) */}
                <span onClick={() => window.scrollTo(0,0)}>Kezdőlap</span>
                <span>Sorozatok</span>
                <span>Filmek</span>
                <span>Saját lista</span>

                {/* Kereső ikon */}
                <i className="fas fa-search" style={{fontSize: '1.1rem', cursor: 'pointer', color: 'white', marginLeft: '10px'}}></i>

                {/* Hamburger menü gomb (Mobilon jelenik meg) */}
                <button className="menu-btn" onClick={() => setMenuOpen(!menuOpen)}>
                    <i className={`fas ${menuOpen ? 'fa-times' : 'fa-bars'}`}></i>
                </button>
            </div>
        </div>
      </nav>

      {/* MOBIL MENÜ LENYÍLÓ ABLAK */}
      {menuOpen && (
        <div style={{
            position: 'fixed',
            top: '70px',
            right: 0,
            width: '250px',
            height: 'calc(100vh - 70px)',
            background: '#0b0f2b', // Sötétkék háttér
            borderLeft: '1px solid rgba(255,255,255,0.1)',
            padding: '30px',
            zIndex: 1999,
            boxShadow: '-5px 0 15px rgba(0,0,0,0.5)',
            display: 'flex',
            flexDirection: 'column'
        }} onClick={() => setMenuOpen(false)}>
            
            <ul style={{
                listStyle: 'none', 
                display: 'flex', 
                flexDirection: 'column', 
                gap: '25px', 
                fontSize: '1.1rem',
                color: 'white'
            }}>
                <li style={{display: 'flex', alignItems: 'center', gap: '15px'}}>
                    <i className="fas fa-home" style={{color: '#3e50ff', width: '20px'}}></i> Kezdőlap
                </li>
                <li style={{display: 'flex', alignItems: 'center', gap: '15px'}}>
                    <i className="fas fa-tv" style={{color: '#3e50ff', width: '20px'}}></i> Sorozatok
                </li>
                <li style={{display: 'flex', alignItems: 'center', gap: '15px'}}>
                    <i className="fas fa-film" style={{color: '#3e50ff', width: '20px'}}></i> Filmek
                </li>
                <li style={{display: 'flex', alignItems: 'center', gap: '15px'}}>
                    <i className="fas fa-heart" style={{color: '#3e50ff', width: '20px'}}></i> Kedvencek
                </li>
            </ul>
        </div>
      )}
    </>
  );
}