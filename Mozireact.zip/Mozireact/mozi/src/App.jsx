
import { useState } from 'react';
import './App.css';

// Komponensek
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import MovieRow from './components/MovieRow';
import ModalManager from './components/ModalManager';

// Adatok
import { moviesData, seriesData } from './data';

function App() {
  const [currentSlide, setCurrentSlide] = useState(0);

  // Modálok
  const [trailerModal, setTrailerModal] = useState({ isOpen: false, videoId: '', title: '' });
  const [infoModal, setInfoModal] = useState({ isOpen: false, movie: null });
  const [streamingModal, setStreamingModal] = useState({ isOpen: false, movie: null });

  // --- LOGIKA ---
  const openTrailer = (videoId, title) => setTrailerModal({ isOpen: true, videoId, title });
  const closeTrailer = () => setTrailerModal({ ...trailerModal, isOpen: false });

  const openInfo = (movie) => setInfoModal({ isOpen: true, movie });
  const closeInfo = () => setInfoModal({ ...infoModal, isOpen: false });

  const openStreaming = (movie) => {
    if(infoModal.isOpen) closeInfo();
    setTimeout(() => {
        setStreamingModal({ isOpen: true, movie });
    }, infoModal.isOpen ? 300 : 0);
  };
  const closeStreaming = () => setStreamingModal({ ...streamingModal, isOpen: false });

  // A filmek listájából levágjuk az elsőt, hogy ne legyen duplikáció a Heroval
  // (Opcionális, de szebb így)
  const remainingMovies = moviesData.slice(0); 

  return (
    <div className='page'>
      
      <Navbar />

      <main>
        {/* HERO SECTION - Ez működött eddig is, de biztosra megyünk */}
        <Hero 
            movies={moviesData.slice(0, 5)} // Csak az első 5 legyen a sliderben
            currentSlide={currentSlide}
            setCurrentSlide={setCurrentSlide}
            onOpenTrailer={openTrailer}
            onOpenInfo={openInfo}
            onOpenStreaming={openStreaming}
        />

        {/* ÖSSZES FILM - Itt adtuk át a javított gombokat */}
        <MovieRow 
            title="Népszerű Filmek" 
            items={remainingMovies} 
            onOpenTrailer={openTrailer} 
            onOpenInfo={openInfo} // Ezt adtuk hozzá!
        />

        {/* SOROZATOK */}
        <MovieRow 
            title="Sorozatok" 
            items={seriesData} 
            isSeries={true} 
            onOpenTrailer={openTrailer} 
            onOpenInfo={openInfo} // Ezt adtuk hozzá!
        />
      </main>

      <footer className="site-footer">
         <p>&copy; 2025 MoziPont. Minden jog fenntartva.</p>
      </footer>

      <ModalManager 
        trailerModal={trailerModal} closeTrailer={closeTrailer}
        infoModal={infoModal} closeInfo={closeInfo}
        streamingModal={streamingModal} closeStreaming={closeStreaming}
        openStreaming={openStreaming}
      />

    </div>
  )
}

export default App;