import { useState, useEffect } from 'react';

// Komponensek importálása
import Navbar from './components/Navbar';
import MovieRow from './components/MovieRow';
import ModalManager from './components/ModalManager';
import AuthModal from './components/AuthModal';
import Toast from './components/Toast';
import ConfirmModal from './components/ConfirmModal';
import Footer from './components/Footer';
import ProfilSzerkeszto from './components/ProfilSzerkeszto'; 
import Sidebar from './components/Sidebar';

// Stílus
import './App.css'; 

function App() {
  // --- STATEK (Állapotok) ---
  
  // Adatok a szerverről
  const [moviesData, setMoviesData] = useState([]);
  const [seriesData, setSeriesData] = useState([]);
  const [featuredMovies, setFeaturedMovies] = useState([]); 
  
  // UI állapotok
  const [loading, setLoading] = useState(true); 
  const [currentSlide, setCurrentSlide] = useState(0);
  const [scrolled, setScrolled] = useState(false);

  // Felhasználó és Auth
  const [user, setUser] = useState(null); 
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  
  // Profil szerkesztő modal állapota
  const [profileModalOpen, setProfileModalOpen] = useState(false);

  // Értesítések
  const [toast, setToast] = useState(null); 

  // Modals (Trailer, Info, Streaming)
  const [trailerModal, setTrailerModal] = useState({ isOpen: false, videoId: '', title: '' });
  const [streamingModal, setStreamingModal] = useState({ isOpen: false, movie: null });
  const [infoModal, setInfoModal] = useState({ isOpen: false, movie: null });

  // --- SIDEBAR STATEK ---
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarType, setSidebarType] = useState('favorites'); // 'favorites' vagy 'mylist'
  const [sidebarItems, setSidebarItems] = useState([]); // A lista tartalma

  // --- 1. ADATOK LEKÉRÉSE (FILMEK/SOROZATOK) ---
  useEffect(() => {
    const fetchAllData = async () => {
      try {
        console.log("Adatok lekérése a szerverről..."); 

        // 1. Filmek lekérése
        const movieResponse = await fetch('http://localhost:3000/api/filmek');
        const movieJson = await movieResponse.json();
        
        // 2. Sorozatok lekérése
        const seriesResponse = await fetch('http://localhost:3000/api/sorozatok');
        const seriesJson = await seriesResponse.json();

        // Állapotok frissítése
        if(movieJson.data) {
            setMoviesData(movieJson.data);
            setFeaturedMovies(movieJson.data.slice(0, 5)); // Az első 5 film a sliderbe
        }

        if(seriesJson.data) {
             setSeriesData(seriesJson.data);
        }

        setLoading(false); 
      } catch (error) {
        console.error("Hiba az adatok lekérésekor:", error);
        setLoading(false);
        showNotification("Nem sikerült kapcsolódni a szerverhez!", "info");
      }
    };

    fetchAllData();
  }, []);

  // --- 2. EGYÉB USE EFFECTS ---

  // Automatikus lapozás a sliderben
  useEffect(() => {
    if (featuredMovies.length === 0) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredMovies.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [featuredMovies]);

  // Navbar színezés görgetésre
  useEffect(() => {
      window.onscroll = () => setScrolled(window.pageYOffset > 50);
      return () => (window.onscroll = null);
  }, []);

  // --- 3. LISTA KEZELŐ FÜGGVÉNYEK (SIDEBARHOZ) ---

  // Lista elemek betöltése (Kedvencek vagy Saját lista)
  const fetchSidebarData = async (type) => {
      if (!user) return;
      const endpoint = type === 'favorites' ? 'favorites' : 'mylist';
      
      try {
          const res = await fetch(`http://localhost:3000/api/interactions/users/${user.id}/${endpoint}`);
          const data = await res.json();
          // Biztonsági ellenőrzés, hogy tömböt kaptunk-e
          setSidebarItems(Array.isArray(data) ? data : []);
      } catch (err) {
          console.error("Hiba a lista betöltésekor", err);
          setSidebarItems([]);
      }
  };

  // Sidebar megnyitása (Navbarból hívjuk)
  const openSidebar = (type) => {
      setSidebarType(type);
      setIsSidebarOpen(true);
      fetchSidebarData(type); // Friss adat betöltése nyitáskor
  };

  // Elem TÖRLÉSE a listából
  const handleDeleteItem = async (itemId) => {
      if (!user) return;
      const endpoint = sidebarType === 'favorites' ? 'favorite' : 'mylist';
      
      try {
          const response = await fetch(`http://localhost:3000/api/interactions/${endpoint}`, {
              method: 'DELETE',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId: user.id, itemId })
          });

          if(response.ok) {
              fetchSidebarData(sidebarType); // Lista frissítése törlés után
              showNotification("Sikeres törlés.", "success");
          } else {
              showNotification("Hiba a törléskor.", "error");
          }
      } catch (err) { 
          console.error("Törlési hiba", err); 
          showNotification("Szerver hiba.", "error");
      }
  };


  // --- 4. INTERAKCIÓK (HOZZÁADÁS) ---

  const showNotification = (message, type = 'success') => {
    setToast({ message, type });
  };

  // KEDVENCEKHEZ ADÁS
  const handleAddToFav = async (movie) => {
    if (!user) {
        showNotification("Jelentkezz be a kedvencekhez!", "info");
        setAuthModalOpen(true);
        return;
    }

    const isSeries = movie.evadok_szama !== undefined || movie.sorozat_id !== undefined;
    const contentId = movie.id || movie._id;

    try {
      const response = await fetch('http://localhost:3000/api/interactions/favorite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          filmId: !isSeries ? contentId : null,
          sorozatId: isSeries ? contentId : null
        })
      });
      
      const result = await response.json();
      if (response.ok) {
        showNotification("Hozzáadva a kedvencekhez!", "success");
      } else {
        showNotification(result.message || "Már a kedvenceid között van.", "info");
      }
    } catch (error) {
      console.error(error);
      showNotification("Hiba történt a mentéskor.", "info");
    }
  };

  // SAJÁT LISTÁHOZ ADÁS
  const handleAddToMyList = async (movie) => {
    if (!user) {
        showNotification("Jelentkezz be a lista kezeléséhez!", "info");
        setAuthModalOpen(true);
        return;
    }
    
    const isSeries = movie.evadok_szama !== undefined || movie.sorozat_id !== undefined;
    const contentId = movie.id || movie._id;

    try {
        const response = await fetch('http://localhost:3000/api/interactions/mylist', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userId: user.id,
                filmId: !isSeries ? contentId : null,
                sorozatId: isSeries ? contentId : null
            })
        });
        
        const result = await response.json();
        if (response.ok) {
            showNotification("Hozzáadva a listához!", "success");
        } else {
            showNotification(result.message || "Már a listádon van.", "info");
        }
    } catch (error) {
        console.error(error);
        showNotification("Hiba történt a mentéskor.", "error");
    }
  };

  // --- 5. USER AUTH & PROFIL ---

  // Bejelentkezés sikeres
  const handleLogin = (userData) => {
    // A backend: { token, user: { id, name, username, ... } }
    setUser(userData.user);
    localStorage.setItem('token', userData.token); 
    showNotification(`Sikeres belépés! Üdv, ${userData.user.name}!`, 'success');
  };

  // Profil mentése
  const handleUpdateProfile = (updatedData) => {
    setUser(prev => ({
      ...prev,
      ...updatedData
    }));
    setProfileModalOpen(false); 
    showNotification('Profil sikeresen frissítve!', 'success');
  };

  // Kijelentkezés
  const initiateLogout = () => {
    setShowLogoutConfirm(true); 
  };

  const confirmLogout = () => {
    setUser(null);
    localStorage.removeItem('token');
    setShowLogoutConfirm(false);
    showNotification('Sikeresen kijelentkeztél.', 'info');
  };

  // --- 6. MODAL KEZELŐK ---
  const openTrailer = (videoId, title) => setTrailerModal({ isOpen: true, videoId, title });
  const closeTrailer = () => setTrailerModal({ ...trailerModal, isOpen: false });

  const openStreaming = (movie) => {
    setInfoModal({ ...infoModal, isOpen: false }); 
    setStreamingModal({ isOpen: true, movie });
  };
  const closeStreaming = () => setStreamingModal({ ...streamingModal, isOpen: false });

  const openInfo = (movie) => setInfoModal({ isOpen: true, movie });
  const closeInfo = () => setInfoModal({ ...infoModal, isOpen: false });

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % featuredMovies.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + featuredMovies.length) % featuredMovies.length);

  // --- TÖLTŐKÉPERNYŐ ---
  if (loading) {
    return (
        <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', background: '#0b0f2b', color: 'white' }}>
            <h2>Adatok betöltése az adatbázisból...</h2>
        </div>
    );
  }

  // --- RENDER ---
  return (
    <div className="page">
      
      {/* 1. NAVBAR */}
      <Navbar 
        scrolled={scrolled} 
        user={user} 
        onOpenAuth={() => setAuthModalOpen(true)}
        onLogout={initiateLogout}
        onUpdateProfile={() => setProfileModalOpen(true)}
        // ÁTADJUK A SIDEBAR NYITÓ FÜGGVÉNYEKET
        onOpenFavorites={() => openSidebar('favorites')} 
        onOpenMyList={() => openSidebar('mylist')}
      />

      {/* --- SIDEBAR --- */}
      <Sidebar 
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        title={sidebarType === 'favorites' ? "Kedvenceim" : "Saját listám"}
        items={sidebarItems}
        onDeleteItem={handleDeleteItem} // Törlés átadása
        onItemClick={(item) => {
            // --- JAVÍTÁS ITT: TELJES ADAT KERESÉSE ---
            
            // 1. Azonosítjuk, hogy filmről vagy sorozatról van szó
            const isMovie = !!item.film_id;
            const idToFind = item.film_id || item.sorozat_id;

            // 2. Megkeressük a TELJES adatot a már betöltött state-ből (moviesData vagy seriesData)
            // Ez azért kell, mert a Sidebar objektumban nincsenek benne a streaming linkek
            let fullMovieObj = null;

            if (isMovie) {
                fullMovieObj = moviesData.find(m => m.id === idToFind);
            } else {
                fullMovieObj = seriesData.find(s => s.id === idToFind);
            }

            // 3. Ha megtaláltuk, azt használjuk. Ha nem (fallback), akkor építünk egyet a sidebar adataiból.
            const movieObj = fullMovieObj || {
                id: idToFind,
                cim: item.film_cim || item.sorozat_cim,
                poszter_url: item.film_poster || item.sorozat_poster,
                leiras: "Részletes adatok jelenleg nem elérhetők.",
                // Opcionális ID-k megőrzése
                film_id: item.film_id,
                sorozat_id: item.sorozat_id
            };

            setIsSidebarOpen(false);
            openInfo(movieObj); // Most már a teljes adatot adjuk át, amiben van streaming infó!
        }}
      />

      <main>
        {/* HERO SLIDER */}
        {featuredMovies.length > 0 && (
            <section className="featured-section">
                <button className="slider-arrow left" onClick={prevSlide}><i className="fas fa-chevron-left"></i></button>

                <div className="slider-container">
                    {featuredMovies.map((movie, index) => (
                        <div 
                            key={movie.id} 
                            className={`movie-slide-split ${index === currentSlide ? 'active' : ''}`}
                            style={{ backgroundImage: `url(${movie.poszter_url})` }}
                        >
                            <div className="slide-backdrop-blur"></div>
                            <div className="split-content-wrapper">
                                <div className="slide-left-info">
                                    <h1>{movie.cim}</h1>
                                    <div className="movie-meta-tags">
                                        <span className="rating-tag"><i className="fas fa-star"></i> {movie.rating}</span>
                                        <span className="year-tag">{movie.megjelenes_ev}</span>
                                        <span className="genre-tag">{movie.kategoria}</span>
                                    </div>
                                    <div className="description-block">
                                        <p className="plot">{movie.leiras}</p>
                                        <div className="credits">
                                            <p><strong>Rendező:</strong> {movie.rendezo}</p>
                                        </div>
                                    </div>
                                    <div className="info-buttons">
                                        <button className="btn-watch" onClick={() => openStreaming(movie)}>
                                            <i className="fas fa-play"></i> Megnézem
                                        </button>
                                        {/* Kedvencek gomb a sliderben */}
                                        <button 
                                            className="btn-watch" 
                                            style={{background: 'rgba(255,255,255,0.2)', marginLeft:'10px'}} 
                                            onClick={() => handleAddToFav(movie)}
                                        >
                                             <i className="fas fa-heart"></i>
                                        </button>
                                         {/* Saját lista gomb a sliderben */}
                                         <button 
                                            className="btn-watch" 
                                            style={{background: 'rgba(255,255,255,0.2)', marginLeft:'10px'}} 
                                            onClick={() => handleAddToMyList(movie)}
                                        >
                                             <i className="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div className="slide-right-image-frame">
                                    <img src={movie.poszter_url} alt={movie.cim} />
                                    <button className="play-btn-on-image" onClick={() => openTrailer(movie.elozetes_url, movie.cim)}>
                                        <i className="fas fa-play"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                <button className="slider-arrow right" onClick={nextSlide}><i className="fas fa-chevron-right"></i></button>
            </section>
        )}

        {/* TARTALOM (Filmek és Sorozatok) */}
        <div className="content-container">
            {moviesData.length > 0 && (
                <MovieRow 
                    title="Népszerű filmek" 
                    items={moviesData} 
                    user={user}
                    onOpenTrailer={openTrailer} 
                    onOpenStreaming={openStreaming} 
                    onOpenInfo={openInfo} 
                    onAddToFav={handleAddToFav}
                    onAddToList={handleAddToMyList} // ÁTADJUK A LISTA GOMB LOGIKÁJÁT
                />
            )}
            
            {seriesData.length > 0 && (
                <MovieRow 
                    title="Népszerű sorozatok" 
                    items={seriesData} 
                    user={user}
                    isSeries={true} 
                    onOpenTrailer={openTrailer} 
                    onOpenStreaming={openStreaming} 
                    onOpenInfo={openInfo} 
                    onAddToFav={handleAddToFav}
                    onAddToList={handleAddToMyList} // ÁTADJUK A LISTA GOMB LOGIKÁJÁT
                />
            )}
        </div>
      </main>

      <Footer />

      {/* --- MODALOK --- */}
      <ModalManager 
        trailerModal={trailerModal} closeTrailer={closeTrailer}
        infoModal={infoModal} closeInfo={closeInfo}
        streamingModal={streamingModal} closeStreaming={closeStreaming}
        openStreaming={openStreaming}
      />
      
      {authModalOpen && <AuthModal onClose={() => setAuthModalOpen(false)} onLogin={handleLogin} />}
      
      {profileModalOpen && user && <ProfilSzerkeszto user={user} onClose={() => setProfileModalOpen(false)} onSave={handleUpdateProfile} />}
      
      <ConfirmModal isOpen={showLogoutConfirm} onClose={() => setShowLogoutConfirm(false)} onConfirm={confirmLogout} title="Kijelentkezés" message="Biztosan ki szeretnél lépni a fiókodból?" />
      
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}

export default App;