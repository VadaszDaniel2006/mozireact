import React from 'react';
// Nincs szükség router importra!

// FONTOS: add hozzá az 'onOpenStreaming'-et a props-ok felsorolásához!
const MovieCard = ({ movie, user, onOpenInfo, onOpenTrailer, onOpenStreaming, onAddToFav, onAddToList }) => {
  if (!movie) return null;

  return (
    <div className="movie-card-container">
      {/* 1. KÉP KATTINTÁS -> TRAILER (Ez volt a kérésed egyik fele) */}
      <div 
        className="movie-card" 
        onClick={() => onOpenTrailer(movie.elozetes_url, movie.cim)}
      >
        <div className="card-image">
          <img src={movie.poszter_url || movie.poster} alt={movie.cim} />
          <div className="card-overlay">
            {/* Ikon jelzi, hogy itt trailer indul */}
            <i className="fas fa-play-circle"></i>
          </div>
        </div>

        {user && (
          <div className="user-interactions" onClick={(e) => e.stopPropagation()}>
            <button className="btn-fav" onClick={(e) => { e.stopPropagation(); onAddToFav(movie); }} title="Kedvencek">
              <i className="fas fa-heart"></i>
            </button>
            <button className="btn-add-list" onClick={(e) => { e.stopPropagation(); onAddToList(movie); }} title="Saját lista">
              <i className="fas fa-plus"></i>
            </button>
          </div>
        )}
      </div>

      <div className="card-details">
        <h4>{movie.cim || movie.title}</h4>
        <div className="card-meta">
          <span>{movie.megjelenes_ev || movie.year}</span>
          <span><i className="fas fa-star"></i> {movie.rating}</span>
        </div>
      </div>

      <div className="card-buttons">
        {/* 2. MEGNÉZEM GOMB -> STREAMING MODAL (Ez volt a kérésed másik fele) */}
        <button 
            className="btn-card-play" 
            onClick={(e) => { 
                e.stopPropagation(); 
                onOpenStreaming(movie); // Ez nyitja meg a lejátszó ablakot
            }}
        >
          <i className="fas fa-play"></i> Megnézem
        </button>
        
        {/* RÉSZLETEK GOMB -> INFO MODAL */}
        <button className="btn-card-info" onClick={(e) => { e.stopPropagation(); onOpenInfo(movie); }}>
          <i className="fas fa-info-circle"></i> Részletek
        </button>
      </div>
    </div>
  );
};

export default MovieCard;