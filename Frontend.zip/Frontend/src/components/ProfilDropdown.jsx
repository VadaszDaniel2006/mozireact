import React, { useState, useRef, useEffect } from 'react';

// Kiegészítettem a props-okat az új függvényekkel
export default function ProfilDropdown({ user, onLogout, onOpenProfile, onOpenFavorites, onOpenMyList }) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Kattintás kívülre (bezárja a menüt)
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="profil-container" ref={dropdownRef}>
      
      {/* 1. GOMB (Avatar + Név + Nyíl) */}
      <div className="profil-btn" onClick={() => setIsOpen(!isOpen)}>
        <div className="profil-avatar-small">
          <img 
            src={user?.avatar || 'https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png'} 
            alt={user?.username || 'User'} 
          />
        </div>
        <span className="profil-name">
            {user?.name || user?.username || 'Felhasználó'}
        </span>
        <i className={`fas fa-chevron-${isOpen ? 'up' : 'down'}`}></i>
      </div>

      {/* 2. LENYÍLÓ MENÜ */}
      {isOpen && (
        <div className="profil-menu">
          
          {/* Fejléc */}
          <div className="profil-header">
            <div className="profil-avatar-large">
               <img 
                 src={user?.avatar || 'https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png'} 
                 alt={user?.username} 
               />
            </div>
            <div className="profil-info">
                <h4>{user?.name}</h4>
                <p>@{user?.username}</p>
                {/* Kedvenc kategóriák */}
                {user?.favoriteCategories && (
                    <div className="profil-tags">
                        {user.favoriteCategories.slice(0, 2).map((cat, i) => (
                            <span key={i} className="profil-tag">{cat}</span>
                        ))}
                        {user.favoriteCategories.length > 2 && (
                            <span className="profil-tag">+{user.favoriteCategories.length - 2}</span>
                        )}
                    </div>
                )}
            </div>
          </div>

          {/* Menüpontok */}
          <div className="profil-menu-items">
            
            <button 
                className="menu-item" 
                onClick={() => {
                    setIsOpen(false);
                    if (onOpenProfile) onOpenProfile();
                }}
            >
                <i className="fas fa-edit"></i> Profil szerkesztése
            </button>
            
            {/* --- JAVÍTVA: KEDVENCEK GOMB BEKÖTÉSE --- */}
            <button 
                className="menu-item"
                onClick={() => {
                    setIsOpen(false);
                    if (onOpenFavorites) onOpenFavorites(); // Sidebar nyitása
                }}
            >
                <i className="fas fa-heart"></i> Kedvenceim
            </button>

            {/* --- JAVÍTVA: SAJÁT LISTA GOMB BEKÖTÉSE --- */}
            <button 
                className="menu-item"
                onClick={() => {
                    setIsOpen(false);
                    if (onOpenMyList) onOpenMyList(); // Sidebar nyitása
                }}
            >
                <i className="fas fa-list"></i> Saját listáim
            </button>

            <div className="menu-divider"></div>

            <button className="menu-item logout" onClick={onLogout}>
                <i className="fas fa-sign-out-alt"></i> Kijelentkezés
            </button>
          </div>
        </div>
      )}
    </div>
  );
}