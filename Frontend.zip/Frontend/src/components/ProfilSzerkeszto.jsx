import React, { useState } from 'react';

// Kategóriák listája (ikonokkal)
const CATEGORIES = [
    { id: 'action', name: 'Akció', icon: '🔥' },
    { id: 'comedy', name: 'Vígjáték', icon: '😂' },
    { id: 'drama', name: 'Dráma', icon: '🎭' },
    { id: 'scifi', name: 'Sci-Fi', icon: '🚀' },
    { id: 'horror', name: 'Horror', icon: '👻' },
    { id: 'romance', name: 'Romantikus', icon: '❤️' },
    { id: 'animation', name: 'Animáció', icon: '🎨' },
    { id: 'thriller', name: 'Thriller', icon: '🔍' },
    { id: 'fantasy', name: 'Fantasy', icon: '🐉' },
    { id: 'docu', name: 'Dokumentum', icon: '📹' }
];

export default function ProfilSzerkeszto({ user, onClose, onSave }) {
    // Statek az űrlaphoz
    const [formData, setFormData] = useState({
        name: user.name || '',
        username: user.username || '',
        email: user.email || '',
        avatar: user.avatar || 'https://via.placeholder.com/150', // Alapértelmezett kép
        favoriteCategories: user.favoriteCategories || []
    });

    const [previewImage, setPreviewImage] = useState(user.avatar || 'https://via.placeholder.com/150');

    // Kép kiválasztása
    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreviewImage(reader.result); // Előnézet frissítése
                setFormData({ ...formData, avatar: reader.result }); // Itt base64-ként mentjük (ideiglenesen)
            };
            reader.readAsDataURL(file);
        }
    };

    // Adatok módosítása
    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    // Kategória váltás (több is kiválasztható, max 5)
    const toggleCategory = (catId) => {
        let newCategories = [...formData.favoriteCategories];
        if (newCategories.includes(catId)) {
            newCategories = newCategories.filter(id => id !== catId);
        } else {
            if (newCategories.length < 5) {
                newCategories.push(catId);
            }
        }
        setFormData({ ...formData, favoriteCategories: newCategories });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave(formData); // Visszaküldjük a frissített adatokat az App.jsx-nek
        onClose();
    };

    return (
        <div className="profile-modal-overlay" onClick={onClose}>
            <div className="profile-modal-content" onClick={e => e.stopPropagation()}>
                
                {/* FEJLÉC */}
                <div className="profile-modal-header">
                    <h3><i className="fas fa-user-edit"></i> Profil szerkesztése</h3>
                    <button className="profile-close-modal" onClick={onClose}>&times;</button>
                </div>

                <div className="profile-modal-body">
                    
                    {/* 1. PROFILKÉP CSERE - JAVÍTOTT MEGJELENÉS */}
                    <div className="avatar-section" style={{ textAlign: 'center', marginBottom: '20px' }}>
                        <div className="avatar-preview" style={{ position: 'relative', display: 'inline-block' }}>
                            <img 
                                src={previewImage} 
                                alt="Profilkép" 
                                style={{ 
                                    width: '120px', 
                                    height: '120px', 
                                    borderRadius: '50%', 
                                    objectFit: 'cover', 
                                    border: '3px solid #3e50ff',
                                    marginBottom: '10px'
                                }}
                            />
                            <br />
                            <label htmlFor="avatar-upload" className="avatar-change-btn" style={{ cursor: 'pointer', color: '#3e50ff', fontWeight: 'bold' }}>
                                <i className="fas fa-camera"></i> Kép módosítása
                            </label>
                            <input 
                                id="avatar-upload" 
                                type="file" 
                                accept="image/*" 
                                style={{ display: 'none' }} 
                                onChange={handleImageChange}
                            />
                        </div>
                    </div>

                    {/* 2. ALAPADATOK - TÉRKÖZÖK JAVÍTÁSA */}
                    <div className="form-section">
                        <h4 style={{ marginBottom: '20px' }}><i className="fas fa-info-circle"></i> Személyes adatok</h4>
                        
                        <div className="input-group" style={{ marginBottom: '20px' }}>
                            <input 
                                type="text" name="name" placeholder=" " 
                                value={formData.name} onChange={handleChange} 
                            />
                            <label>Teljes név</label>
                        </div>

                        <div className="input-group" style={{ marginBottom: '20px' }}>
                            <input 
                                type="text" name="username" placeholder=" " 
                                value={formData.username} onChange={handleChange} 
                            />
                            <label>Felhasználónév</label>
                        </div>

                        <div className="input-group" style={{ marginBottom: '20px' }}>
                            <input 
                                type="email" name="email" placeholder=" " 
                                value={formData.email} onChange={handleChange} disabled
                                style={{opacity: 0.7, cursor: 'not-allowed'}}
                            />
                            <label>Email cím (nem módosítható)</label>
                        </div>
                    </div>

                    {/* 3. KEDVENC KATEGÓRIÁK */}
                    <div className="form-section">
                        <h4><i className="fas fa-heart"></i> Kedvenc kategóriák</h4>
                        <p className="section-subtitle">Válassz ki legfeljebb 5 kategóriát, ami érdekel!</p>

                        <div className="categories-container">
                            <div className="categories-grid">
                                {CATEGORIES.map(cat => (
                                    <div 
                                        key={cat.id} 
                                        className={`category-item ${formData.favoriteCategories.includes(cat.id) ? 'selected' : ''}`}
                                        onClick={() => toggleCategory(cat.id)}
                                    >
                                        <span className="category-icon">{cat.icon}</span>
                                        <span className="category-name">{cat.name}</span>
                                        {formData.favoriteCategories.includes(cat.id) && (
                                            <div className="category-check"><i className="fas fa-check"></i></div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="selection-count">
                            Kiválasztva: {formData.favoriteCategories.length} / 5
                        </div>
                    </div>

                    {/* GOMBOK */}
                    <div className="modal-actions">
                        <button type="button" className="btn-cancel" onClick={onClose}>Mégse</button>
                        <button type="button" className="btn-save" onClick={handleSubmit}>
                            <i className="fas fa-save"></i> Mentés
                        </button>
                    </div>

                </div>
            </div>
        </div>
    );
}