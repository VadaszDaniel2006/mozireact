// src/routes/interactionRoutes.js
const express = require('express');
const router = express.Router();
const interactionController = require('../controllers/interactionController');

// --- KEDVENCEK (Favorites) ---
// Hozzáadás
router.post('/favorite', interactionController.addToFavorites);
// Törlés
router.delete('/favorite', interactionController.removeFromFavorites);
// Listázás (Sidebarhoz)
router.get('/users/:userId/favorites', interactionController.getFavorites);


// --- JAVÍTÁS: SAJÁT LISTA (My List) ÚTVONALAK HOZZÁADÁSA ---
// Ez hiányzott, ezért kaptad a 404 hibát:

// Hozzáadás saját listához
router.post('/mylist', interactionController.addToMyList);

// Törlés saját listából
router.delete('/mylist', interactionController.removeFromMyList);

// Saját lista lekérése (Sidebarhoz)
router.get('/users/:userId/mylist', interactionController.getMyList);

module.exports = router;