const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// --- REGISZTRÁCIÓ ---
exports.register = async (req, res) => {
    const { name, email, password, username, favoriteCategories } = req.body;

    // 1. Ellenőrzés: Minden kötelező mező megérkezett-e?
    if (!name || !email || !password || !username) {
        return res.status(400).json({ message: 'Minden mező kitöltése kötelező!' });
    }

    try {
        // 2. Duplikáció ellenőrzése
        const [existing] = await db.query('SELECT * FROM users WHERE email = ? OR username = ?', [email, username]);
        
        if (existing.length > 0) {
            if (existing[0].email === email) {
                return res.status(400).json({ message: 'Ez az email cím már foglalt!' });
            }
            if (existing[0].username === username) {
                return res.status(400).json({ message: 'Ez a felhasználónév már foglalt!' });
            }
        }

        // 3. Jelszó titkosítása
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // 4. Felhasználó beszúrása
        // MEGJEGYZÉS: A diagramon 'nev' szerepel, a kódban 'name'-et kaptunk. 
        // Feltételezem a DB-ben 'nev' az oszlop neve. Ha 'name', írd át!
        const sql = `INSERT INTO users (nev, email, password_hash, username, role, regisztracio_datum) VALUES (?, ?, ?, ?, 'user', NOW())`;
        const [result] = await db.query(sql, [name, email, hashedPassword, username]);
        const newUserId = result.insertId;

        // 5. Alapértelmezett "Saját listám" létrehozása
        // Csak akkor fut le, ha van 'custom_lists' tábla
        try {
            await db.query(
                'INSERT INTO custom_lists (user_id, title, created_at) VALUES (?, ?, NOW())',
                [newUserId, 'Saját listám']
            );
        } catch (listErr) {
            console.warn("Nem sikerült alapértelmezett listát létrehozni (nem kritikus):", listErr.message);
        }

        // 6. Kedvenc kategóriák mentése (JAVÍTÁS: TÖMEGES BESZÚRÁS)
        if (favoriteCategories && Array.isArray(favoriteCategories) && favoriteCategories.length > 0) {
            // A mysql2 bulk insert-hez tömbök tömbje kell: [[id, 'action'], [id, 'scifi']]
            const categoryValues = favoriteCategories.map(cat => [newUserId, cat]);
            
            await db.query(
                'INSERT INTO user_favorite_categories (user_id, category_id) VALUES ?', 
                [categoryValues]
            );
        }

        res.status(201).json({ message: 'Sikeres regisztráció! Most már bejelentkezhetsz.' });

    } catch (error) {
        // KIEMELTEN FONTOS: Ez kiírja a pontos hibát a VS Code termináljába
        console.error("PONTOS REGISZTRÁCIÓS HIBA:", error.message);
        res.status(500).json({ message: 'Szerver hiba történt a regisztráció során.', error: error.message });
    }
};

// --- BEJELENTKEZÉS ---
exports.login = async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'Email és jelszó megadása kötelező!' });
    }

    try {
        const [users] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
        
        if (users.length === 0) {
            return res.status(400).json({ message: 'Hibás email vagy jelszó!' });
        }

        const user = users[0];

        const isMatch = await bcrypt.compare(password, user.password_hash);
        
        if (!isMatch) {
            return res.status(400).json({ message: 'Hibás email vagy jelszó!' });
        }

        // --- JAVÍTÁS: KATEGÓRIÁK BETÖLTÉSE ---
        // Lekérjük a mentett kategóriákat, hogy a frontend tudja, mik voltak bejelölve
        let favoriteCategoriesList = [];
        try {
            const [categoriesDB] = await db.query(
                'SELECT category_id FROM user_favorite_categories WHERE user_id = ?', 
                [user.id]
            );
            // Átalakítás egyszerű tömbbé: ['action', 'horror']
            favoriteCategoriesList = categoriesDB.map(row => row.category_id);
        } catch (catErr) {
            console.warn("Hiba a kategóriák betöltésekor (nem kritikus):", catErr.message);
        }

        const token = jwt.sign(
            { id: user.id, role: user.role }, 
            process.env.JWT_SECRET || 'titkoskulcs', 
            { expiresIn: '2h' }
        );

        res.json({
            token,
            user: {
                id: user.id,
                name: user.nev,
                username: user.username, 
                email: user.email,
                avatar: user.avatar || "https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png",
                role: user.role,
                favoriteCategories: favoriteCategoriesList // <--- VISSZAKÜLDJÜK A KATEGÓRIÁKAT
            }
        });

    } catch (error) {
        console.error("Bejelentkezési hiba:", error.message);
        res.status(500).json({ message: 'Szerver hiba történt a bejelentkezés során.' });
    }
};