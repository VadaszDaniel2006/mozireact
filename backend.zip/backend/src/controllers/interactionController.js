const db = require('../config/db'); // Az adatbázis kapcsolatod

// =========================================================
// --- KEDVENCEK KEZELÉSE (Favorites) ---
// =========================================================

// --- KEDVENCEK HOZZÁADÁSA ---
exports.addToFavorites = async (req, res) => {
    const { userId, filmId, sorozatId } = req.body;

    if (!userId || (!filmId && !sorozatId)) {
        return res.status(400).json({ message: "Hiányzó adatok (userId, filmId vagy sorozatId)!" });
    }

    try {
        const [existing] = await db.query(
            'SELECT * FROM kedvencek WHERE user_id = ? AND (film_id = ? OR sorozat_id = ?)',
            [userId, filmId || null, sorozatId || null]
        );

        if (existing.length > 0) {
            return res.status(400).json({ message: "Ez a tétel már a kedvencek között van!" });
        }

        await db.query(
            'INSERT INTO kedvencek (user_id, film_id, sorozat_id, added_at) VALUES (?, ?, ?, NOW())',
            [userId, filmId || null, sorozatId || null]
        );

        res.status(200).json({ message: "Sikeresen hozzáadva a kedvencekhez!" });
    } catch (err) {
        console.error("Hiba a kedvencek mentésekor:", err);
        res.status(500).json({ message: "Szerver hiba" });
    }
};

// --- KEDVENCEK LEKÉRÉSE (Sidebarhoz) ---
exports.getFavorites = async (req, res) => {
    const { userId } = req.params;

    try {
        // JAVÍTVA: f.poszter_url és s.poszter_url (a régi kód f.poszter-t keresett)
        const query = `
            SELECT k.id, k.added_at,
                   f.id as film_id, f.cim as film_cim, f.poszter_url as film_poster,
                   s.id as sorozat_id, s.cim as sorozat_cim, s.poszter_url as sorozat_poster
            FROM kedvencek k
            LEFT JOIN filmek f ON k.film_id = f.id
            LEFT JOIN sorozatok s ON k.sorozat_id = s.id
            WHERE k.user_id = ?
            ORDER BY k.added_at DESC
        `;

        const [results] = await db.query(query, [userId]);
        res.status(200).json(results);
    } catch (err) {
        console.error("Hiba a kedvencek lekérésekor:", err);
        res.status(500).json({ message: "Szerver hiba: " + err.message });
    }
};

// --- TÖRLÉS KEDVENCEKBŐL ---
exports.removeFromFavorites = async (req, res) => {
    const { userId, itemId } = req.body;
    try {
        await db.query('DELETE FROM kedvencek WHERE user_id = ? AND id = ?', [userId, itemId]);
        res.status(200).json({ message: "Törölve." });
    } catch (err) {
        console.error("Hiba törléskor:", err);
        res.status(500).json({ message: "Hiba törléskor." });
    }
};

// =========================================================
// --- SAJÁT LISTA KEZELÉSE (Custom Lists) ---
// =========================================================

// --- SAJÁT LISTÁHOZ ADÁS ---
exports.addToMyList = async (req, res) => {
    const { userId, filmId, sorozatId } = req.body;

    if (!userId) return res.status(400).json({ message: "Nincs bejelentkezve!" });

    try {
        let [lists] = await db.query('SELECT id FROM custom_lists WHERE user_id = ? LIMIT 1', [userId]);
        
        let listId;

        if (lists.length === 0) {
            const [newList] = await db.query(
                'INSERT INTO custom_lists (user_id, title, is_public, created_at) VALUES (?, "Saját listám", 0, NOW())',
                [userId]
            );
            listId = newList.insertId;
        } else {
            listId = lists[0].id;
        }

        const [existingItem] = await db.query(
            'SELECT * FROM custom_list_items WHERE list_id = ? AND (film_id = ? OR sorozat_id = ?)',
            [listId, filmId || null, sorozatId || null]
        );

        if (existingItem.length > 0) {
            return res.status(400).json({ message: "Már a listádon van!" });
        }

        await db.query(
            'INSERT INTO custom_list_items (list_id, film_id, sorozat_id, added_at) VALUES (?, ?, ?, NOW())',
            [listId, filmId || null, sorozatId || null]
        );

        res.status(200).json({ message: "Hozzáadva a saját listához!" });

    } catch (err) {
        console.error("Hiba a lista mentésekor:", err);
        res.status(500).json({ message: "Szerver hiba" });
    }
};

// --- SAJÁT LISTA LEKÉRÉSE ---
exports.getMyList = async (req, res) => {
    const { userId } = req.params;

    try {
        // JAVÍTVA: f.poszter_url és s.poszter_url
        const query = `
            SELECT cli.id, cli.added_at,
                   f.id as film_id, f.cim as film_cim, f.poszter_url as film_poster,
                   s.id as sorozat_id, s.cim as sorozat_cim, s.poszter_url as sorozat_poster
            FROM custom_list_items cli
            JOIN custom_lists cl ON cli.list_id = cl.id
            LEFT JOIN filmek f ON cli.film_id = f.id
            LEFT JOIN sorozatok s ON cli.sorozat_id = s.id
            WHERE cl.user_id = ?
            ORDER BY cli.added_at DESC
        `;

        const [results] = await db.query(query, [userId]);
        res.status(200).json(results);
    } catch (err) {
        console.error("Hiba a lista lekérésekor:", err);
        res.status(500).json({ message: "Szerver hiba: " + err.message });
    }
};

// --- TÖRLÉS SAJÁT LISTÁBÓL ---
exports.removeFromMyList = async (req, res) => {
    const { userId, itemId } = req.body; 
    try {
        await db.query('DELETE FROM custom_list_items WHERE id = ?', [itemId]);
        res.status(200).json({ message: "Törölve." });
    } catch (err) {
        console.error("Hiba törléskor:", err);
        res.status(500).json({ message: "Hiba törléskor." });
    }
};