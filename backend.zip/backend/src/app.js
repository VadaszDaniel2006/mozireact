const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

// Importáld a route-okat
const authRoutes = require('./routes/authRoutes');
const movieRoutes = require('./routes/movieRoutes');
const seriesRoutes = require('./routes/seriesRoutes');
const interactionRoutes = require('./routes/interactionRoutes'); // <-- ÚJ: Ezt a sort add hozzá!

const app = express();

app.use(helmet());
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());

// Végpontok használata
app.use('/api/auth', authRoutes);
app.use('/api/filmek', movieRoutes);
app.use('/api/sorozatok', seriesRoutes);
app.use('/api/interactions', interactionRoutes); // <-- ÚJ: Ezt a sort is add hozzá!

app.use((req, res) => {
    res.status(404).json({ message: 'Az útvonal nem található' });
});

module.exports = app;