const db = require('../config/db');

exports.getAllMovies = async (req, res) => {
    try {
        const query = `
            SELECT 
                f.*,
                k.nev AS kategoria,
                r.nev AS rendezo,
                
                -- RÉGI MYSQL KOMPATIBILIS MEGOLDÁS (JSON HELYETT STRING)
                -- Összefűzzük a platformokat egy hosszú szöveggé: "Netflix|||logo.jpg|||url;;;HBO|||logo2.jpg|||url2"
                GROUP_CONCAT(
                    CONCAT_WS('|||', p.nev, IFNULL(p.logo_url, ''), IFNULL(p.weboldal_url, '')) 
                    SEPARATOR ';;;'
                ) AS platform_raw

            FROM filmek f
            LEFT JOIN kategoriak k ON f.kategoria_id = k.id
            LEFT JOIN rendezok r ON f.rendezo_id = r.id
            -- Itt kötjük be a több platformot
            LEFT JOIN film_platformok fp ON f.id = fp.film_id
            LEFT JOIN platformok p ON fp.platform_id = p.id
            
            GROUP BY f.id
            ORDER BY f.id ASC
        `;
        
        const [rows] = await db.query(query);

        // UTÓLAGOS FELDOLGOZÁS (STRING -> JSON LISTA)
        const movies = rows.map(movie => {
            let platform_lista = [];
            
            if (movie.platform_raw) {
                // Szétvágjuk a hosszú szöveget darabokra
                const entries = movie.platform_raw.split(';;;');
                
                platform_lista = entries.map(entry => {
                    const [nev, logo, url] = entry.split('|||');
                    return { nev, logo, url };
                });
            }

            // Töröljük a csúnya technikai mezőt, és betesszük a szép listát
            delete movie.platform_raw;
            return { ...movie, platform_lista };
        });
        
        res.status(200).json({ data: movies });

    } catch (error) {
        console.error("Hiba a filmek lekérésekor:", error);
        res.status(500).json({ message: "Szerver hiba történt." });
    }
};