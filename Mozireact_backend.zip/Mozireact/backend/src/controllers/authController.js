// src/controllers/authController.js
const db = require('../config/db');
const bcrypt = require('bcryptjs'); // Jelszó titkosító
const jwt = require('jsonwebtoken'); // Token generáló

// --- REGISZTRÁCIÓ ---
exports.register = async (req, res) => {
    const { name, email, password, username } = req.body;

    try {
        // 1. Ellenőrizzük, létezik-e már az email
        const [existingUser] = await db.query('SELECT * FROM tagok WHERE email = ?', [email]);
        if (existingUser.length > 0) {
            return res.status(400).json({ message: 'Ez az email cím már foglalt!' });
        }

        // 2. Jelszó titkosítása (HASHELÉS)
        // A '10' a "sózás" mértéke (hogy ne lehessen visszafejteni)
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // 3. Felhasználó mentése az adatbázisba
        // A képed alapján a tagok tábla mezői: nev, email, jelszo, profilkep_url, regisztracio_datum
        const sql = `INSERT INTO tagok (nev, email, jelszo, profilkep_url) VALUES (?, ?, ?, ?)`;
        const defaultAvatar = "https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png";
        
        await db.query(sql, [name, email, hashedPassword, defaultAvatar]);

        res.status(201).json({ message: 'Sikeres regisztráció! Most már bejelentkezhetsz.' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Szerver hiba történt.' });
    }
};

// --- BEJELENTKEZÉS ---
exports.login = async (req, res) => {
    const { email, password } = req.body;

    try {
        // 1. Felhasználó keresése email alapján
        const [users] = await db.query('SELECT * FROM tagok WHERE email = ?', [email]);
        
        if (users.length === 0) {
            return res.status(400).json({ message: 'Hibás email vagy jelszó!' });
        }

        const user = users[0];

        // 2. Jelszó ellenőrzése (Összehasonlítjuk a beírtat a titkosítottal)
        const isMatch = await bcrypt.compare(password, user.jelszo);
        
        if (!isMatch) {
            return res.status(400).json({ message: 'Hibás email vagy jelszó!' });
        }

        // 3. Token generálás (Ez a "belépőkártya")
        // A Frontend ezt fogja megkapni és elmenteni
        const token = jwt.sign(
            { id: user.id }, 
            process.env.JWT_SECRET || 'titkoskulcs123', // Ezt majd tedd a .env fájlba!
            { expiresIn: '1h' } // 1 óráig érvényes
        );

        // 4. Válasz küldése a Frontendnek (jelszó nélkül!)
        res.json({
            token,
            user: {
                id: user.id,
                name: user.nev,
                email: user.email,
                avatar: user.profilkep_url
            }
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Szerver hiba történt.' });
    }
};