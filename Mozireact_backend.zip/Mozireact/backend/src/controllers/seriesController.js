const db = require('../config/db');

exports.getAllSeries = async (req, res) => {
    try {
        const query = `
            SELECT 
                s.*,
                k.nev AS kategoria,
                r.nev AS rendezo,
                
                -- RÉGI MYSQL KOMPATIBILIS MEGOLDÁS
                GROUP_CONCAT(
                    CONCAT_WS('|||', p.nev, IFNULL(p.logo_url, ''), IFNULL(p.weboldal_url, '')) 
                    SEPARATOR ';;;'
                ) AS platform_raw

            FROM sorozatok s
            LEFT JOIN kategoriak k ON s.kategoria_id = k.id
            LEFT JOIN rendezok r ON s.rendezo_id = r.id
            LEFT JOIN sorozat_platformok sp ON s.id = sp.sorozat_id
            LEFT JOIN platformok p ON sp.platform_id = p.id
            
            GROUP BY s.id
            ORDER BY s.id ASC
        `;
        
        const [rows] = await db.query(query);

        // FELDOLGOZÁS
        const series = rows.map(serie => {
            let platform_lista = [];
            
            if (serie.platform_raw) {
                const entries = serie.platform_raw.split(';;;');
                platform_lista = entries.map(entry => {
                    const [nev, logo, url] = entry.split('|||');
                    return { nev, logo, url };
                });
            }

            delete serie.platform_raw;
            return { ...serie, platform_lista };
        });
        
        res.status(200).json({ data: series });

    } catch (error) {
        console.error("Hiba a sorozatok lekérésekor:", error);
        res.status(500).json({ message: "Szerver hiba történt." });
    }
};