import React from 'react';
// TÖRÖLTÜK: import { platformsInfo } from '../data'; -> Erre már nincs szükség!

export default function ModalManager({ 
  trailerModal, closeTrailer, 
  infoModal, closeInfo, openStreaming,
  streamingModal, closeStreaming 
}) {
  
  // --- 1. HELYI SEGÉDFÜGGVÉNY A PLATFORM KEZELÉSÉHEZ ---
  const getPlatformData = (movie) => {
    // Ha az adatbázisból jön az adat (van platform_nev)
    if (movie.platform_nev) {
        return {
            name: movie.platform_nev,
            logo: movie.platform_logo, // Ez jön az SQL-ből
            url: movie.platform_link || '#'
        };
    }
    // Ha esetleg régi adat (fallback)
    return {
        name: "Ismeretlen szolgáltató",
        logo: null,
        url: "#"
    };
  };

  return (
    <>
      {/* 1. TRAILER MODAL (Előzetes) */}
      {trailerModal.isOpen && (
        <div className="modal active" onClick={closeTrailer}>
          <div className="modal-content modal-lg" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{trailerModal.title} - Előzetes</h3>
              <button className="close-modal" onClick={closeTrailer}><i className="fas fa-times"></i></button>
            </div>
            <div className="video-container">
              <iframe 
                width="100%" height="500" 
                // Itt feltételezzük, hogy a videoId maga a YouTube ID (pl. dQw4w9WgXcQ)
                src={`https://www.youtube.com/embed/${trailerModal.videoId}?autoplay=1`} 
                title="Trailer" frameBorder="0" allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      )}

      {/* 2. INFO MODAL (Részletek) */}
      {infoModal.isOpen && infoModal.movie && (
        <div className="modal active" onClick={closeInfo}>
          <div className="modal-content modal-md" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              {/* Cím javítva: cim (DB) vagy title (régi) */}
              <h3>{infoModal.movie.cim || infoModal.movie.title} - Részletek</h3>
              <button className="close-modal" onClick={closeInfo}><i className="fas fa-times"></i></button>
            </div>
            
            <div className="info-layout">
              <div className="info-poster">
                {/* KÉP JAVÍTVA: poszter_url (DB) vagy poster (régi) */}
                <img 
                    src={infoModal.movie.poszter_url || infoModal.movie.poster} 
                    alt={infoModal.movie.cim || infoModal.movie.title} 
                />
              </div>
              
              <div className="info-text">
                <h2>{infoModal.movie.cim || infoModal.movie.title}</h2>
                <div className="info-meta">
                    {/* ÉV JAVÍTVA */}
                    <span>{infoModal.movie.megjelenes_ev || infoModal.movie.year}</span>
                    <span>{infoModal.movie.rating} <i className="fas fa-star" style={{color:'#f5c518'}}></i></span>
                    {/* KATEGÓRIA JAVÍTVA */}
                    <span>{infoModal.movie.kategoria || infoModal.movie.genre}</span>
                </div>
                
                {/* LEÍRÁS JAVÍTVA */}
                <p className="info-desc">{infoModal.movie.leiras || infoModal.movie.description}</p>
                
                <div className="info-credits">
                    <p><strong>Rendező:</strong> {infoModal.movie.rendezo || infoModal.movie.director}</p>
                    {/* Szereplők (ha van adat) */}
                    {(infoModal.movie.actors || infoModal.movie.szereplok) && (
                        <p><strong>Szereplők:</strong> {infoModal.movie.actors || infoModal.movie.szereplok}</p>
                    )}
                </div>

                <div className="info-actions">
                    <button className="btn-modal-action" onClick={() => openStreaming(infoModal.movie)}>
                        <i className="fas fa-play"></i> Megnézem most
                    </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* 3. STREAMING MODAL (Hol nézhető) */}
      {streamingModal.isOpen && streamingModal.movie && (
        <div className="modal active" onClick={closeStreaming}>
          <div className="modal-content modal-sm" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Hol nézheted meg?</h3>
              <button className="close-modal" onClick={closeStreaming}><i className="fas fa-times"></i></button>
            </div>
            
            <div className="streaming-services">
              {/* Itt hívjuk meg a fenti segédfüggvényt */}
              {(() => {
                  const platform = getPlatformData(streamingModal.movie);
                  
                  if (!platform.logo && platform.name === "Ismeretlen szolgáltató") {
                      return <p style={{padding:'20px', color:'#ccc'}}>Nincs elérhető streaming adat ehhez a filmhez.</p>;
                  }

                  return (
                    <div 
                        className="streaming-service" 
                        onClick={() => window.open(platform.url, '_blank')}
                    >
                        <div className="service-logo">
                            {platform.logo ? (
                                <img src={platform.logo} alt={platform.name} />
                            ) : (
                                <i className="fas fa-tv"></i> // Ha nincs logó URL, ikon jelenik meg
                            )}
                        </div>
                        <span>{platform.name}</span>
                        <i className="fas fa-external-link-alt" style={{marginLeft:'auto', color:'#888'}}></i>
                    </div>
                  );
              })()}
            </div>
          </div>
        </div>
      )}
    </>
  );
}