import React from 'react';

export default function MovieRow({ 
    title, 
    items, 
    onOpenTrailer,   
    onOpenStreaming, 
    onOpenInfo,       
    isSeries = false 
}) {
  return (
    <section className="more-movies-section">
      <h2>{title}</h2>
      <div className="movies-grid">
        {items.map((item, index) => (
          <div key={item.id || index} className="movie-card-container"> {/* Jobb az ID-t használni kulcsként */}
            
            {/* 1. KÉP -> TRAILER */}
            <div 
                className="movie-card" 
                // JAVÍTÁS: elozetes_url (DB) vagy trailerId (régi)
                onClick={() => onOpenTrailer(item.elozetes_url || item.trailerId, item.cim || item.title)}
            >
              <div className="card-image">
                {/* JAVÍTÁS: poszter_url (DB) vagy poster (régi) */}
                <img 
                    src={item.poszter_url || item.poster} 
                    alt={item.cim || item.title} 
                    loading="lazy" 
                />
                
                <div className="card-overlay">
                    <i className="fas fa-play-circle"></i>
                </div>

                {isSeries && <div className="series-badge">Sorozat</div>}
              </div>
            </div>

            {/* 2. ADATOK */}
            <div className="card-details">
                {/* JAVÍTÁS: cim (DB) vagy title (régi) */}
                <h4>{item.cim || item.title}</h4>
                <div className="card-meta">
                    {/* JAVÍTÁS: megjelenes_ev (DB) vagy year (régi) */}
                    <span className="year">{item.megjelenes_ev || item.year}</span>
                    <span className="rating"><i className="fas fa-star"></i> {item.rating}</span>
                </div>
            </div>

            {/* 3. GOMBOK */}
            <div className="card-buttons">
                {/* MEGNÉZEM -> STREAMING */}
                <button 
                    className="btn-card-play" 
                    onClick={() => onOpenStreaming(item)}
                >
                    <i className="fas fa-play"></i> Megnézem
                </button>

                {/* RÉSZLETEK -> INFO */}
                <button 
                    className="btn-card-info" 
                    onClick={() => onOpenInfo(item)}
                >
                    <i className="fas fa-info-circle"></i> Részletek
                </button>
            </div>

          </div>
        ))}
      </div>
    </section>
  );
}