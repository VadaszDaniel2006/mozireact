import React, { useState } from 'react';

export default function AuthModal({ onClose, onLogin }) {
  const [isRegister, setIsRegister] = useState(false);
  
  // Űrlap adatok
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    // Validációk regisztrációnál
    if (isRegister) {
        if (password !== confirmPassword) {
            setError("A jelszavak nem egyeznek!");
            return;
        }
        if (password.length < 6) {
            setError("A jelszónak legalább 6 karakternek kell lennie!");
            return;
        }
    }

    // JAVÍTÁS: Felhasználónév generálása
    // Ha regisztrál -> A beírt felhasználónevet használjuk.
    // Ha belép -> Az email cím első részét használjuk (pl. kiss@mail.com -> kiss),
    // így nem a statikus "Felhasználó" szöveg jelenik meg.
    let finalUsername = "";
    let finalName = "";

    if (isRegister) {
        finalUsername = username;
        finalName = name;
    } else {
        // Belépésnél generálunk egy nevet az emailből
        finalUsername = email.split('@')[0]; // Az @ előtti rész
        finalName = finalUsername;
    }

    const userData = {
      name: finalName,
      username: finalUsername, // Itt mentjük el a helyes felhasználónevet
      email: email,
      avatar: "https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png"
    };

    onLogin(userData);
    onClose();
  };

  return (
    <div className="modal active auth-overlay" onClick={onClose}>
      <div className="modal-content auth-card" onClick={(e) => e.stopPropagation()}>
        
        <button className="close-auth" onClick={onClose}>
            <i className="fas fa-times"></i>
        </button>

        <div className="auth-header">
          <h2>{isRegister ? 'Fiók létrehozása' : 'Üdvözlünk újra!'}</h2>
          <p>{isRegister ? 'Regisztrálj a korlátlan filmezéshez.' : 'Jelentkezz be a folytatáshoz.'}</p>
        </div>

        {error && <div className="auth-error">{error}</div>}

        <form onSubmit={handleSubmit} className="auth-form">
          
          {isRegister && (
            <>
                <div className="input-group">
                    <input 
                        type="text" 
                        placeholder=" " 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required 
                        id="name"
                    />
                    <label htmlFor="name">Teljes név</label>
                </div>

                <div className="input-group">
                    <input 
                        type="text" 
                        placeholder=" " 
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required 
                        id="username"
                    />
                    <label htmlFor="username">Felhasználónév</label>
                </div>
            </>
          )}

          <div className="input-group">
            <input 
              type="email" 
              placeholder=" " 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required 
              id="email"
            />
            <label htmlFor="email">Email cím</label>
          </div>

          <div className="input-group">
            <input 
              type="password" 
              placeholder=" " 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required 
              id="password"
            />
            <label htmlFor="password">Jelszó</label>
          </div>

          {isRegister && (
            <div className="input-group">
              <input 
                type="password" 
                placeholder=" " 
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required 
                id="confirmPassword"
              />
              <label htmlFor="confirmPassword">Jelszó megerősítése</label>
            </div>
          )}

          <button type="submit" className="btn-submit-auth">
            {isRegister ? 'Regisztráció' : 'Bejelentkezés'}
          </button>
        </form>

        <div className="auth-footer">
          <p>
            {isRegister ? "Már van fiókod?" : "Még nincs fiókod?"}
            <span onClick={() => { setIsRegister(!isRegister); setError(''); }}>
              {isRegister ? " Lépj be itt" : " Regisztrálj most"}
            </span>
          </p>
        </div>

      </div>
    </div>
  );
}