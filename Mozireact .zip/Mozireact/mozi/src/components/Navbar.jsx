import React, { useState } from 'react';
// Ha a kép az src mappában van:
import logoImg from '../logo.png'; 

export default function Navbar({ scrolled, user, onOpenAuth, onLogout }) {
  const [searchActive, setSearchActive] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  return (
    <nav className={scrolled ? 'scrolled' : ''}>
      <div className="nav-container">
        
        {/* BAL OLDAL */}
        <div className="nav-left">
            <a href="/" className="logo-link">
                <div className="logo">
                    <img src={logoImg} alt="MoziPont Logo" />
                </div>
            </a>
            <ul className="nav-links">
                <li><a href="/">Kezdőlap</a></li>
                <li><a href="#series">Sorozatok</a></li>
                <li><a href="#movies">Filmek</a></li>
                <li><a href="#list">Saját lista</a></li>
            </ul>
        </div>

        {/* JOBB OLDAL */}
        <div className="nav-right">
            <div className={`search-box ${searchActive ? 'active' : ''}`}>
                <button className="search-btn" onClick={() => setSearchActive(!searchActive)}>
                    <i className="fas fa-search"></i>
                </button>
                <input 
                    type="text" 
                    placeholder="Címek, emberek, műfajok..." 
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                />
            </div>
            
            {user ? (
                <div className="user-menu">
                    <img src={user.avatar} alt="User" className="user-avatar" />
                    
                    {/* ITT A JAVÍTÁS: user.username-et írjuk ki elsőként! */}
                    <span className="user-name">
                        {user.username ? user.username : user.name}
                    </span>
                    
                    <button className="btn-logout" onClick={onLogout}>
                        <i className="fas fa-sign-out-alt"></i>
                    </button>
                </div>
            ) : (
                <button className="btn-login" onClick={onOpenAuth}>
                    Bejelentkezés
                </button>
            )}
            
        </div>
      </div>
    </nav>
  );
}