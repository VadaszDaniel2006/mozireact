import React from 'react';

export default function MovieRow({ 
    title, 
    items, 
    onOpenTrailer,   // Ez a képre kattintva indul (Trailer)
    onOpenStreaming, // Ez a "Megnézem" gombra kattintva indul (Streaming)
    onOpenInfo,      // Ez a "Részletek" gomb
    isSeries = false 
}) {
  return (
    <section className="more-movies-section">
      <h2>{title}</h2>
      <div className="movies-grid">
        {items.map((item, index) => (
          <div key={index} className="movie-card-container">
            
            {/* 1. KÉP -> TRAILER */}
            <div 
                className="movie-card" 
                onClick={() => onOpenTrailer(item.trailerId, item.title)}
            >
              <div className="card-image">
                <img src={item.poster} alt={item.title} loading="lazy" />
                
                <div className="card-overlay">
                    <i className="fas fa-play-circle"></i>
                </div>

                {isSeries && <div className="series-badge">Sorozat</div>}
              </div>
            </div>

            {/* 2. ADATOK */}
            <div className="card-details">
                <h4>{item.title}</h4>
                <div className="card-meta">
                    <span className="year">{item.year}</span>
                    <span className="rating"><i className="fas fa-star"></i> {item.rating}</span>
                </div>
            </div>

            {/* 3. GOMBOK */}
            <div className="card-buttons">
                {/* MEGNÉZEM -> STREAMING */}
                <button 
                    className="btn-card-play" 
                    onClick={() => onOpenStreaming(item)}
                >
                    <i className="fas fa-play"></i> Megnézem
                </button>

                {/* RÉSZLETEK -> INFO */}
                <button 
                    className="btn-card-info" 
                    onClick={() => onOpenInfo(item)}
                >
                    <i className="fas fa-info-circle"></i> Részletek
                </button>
            </div>

          </div>
        ))}
      </div>
    </section>
  );
}