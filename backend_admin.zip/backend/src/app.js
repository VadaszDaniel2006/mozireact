const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

// Importáld a route-okat
const authRoutes = require('./routes/authRoutes');
const movieRoutes = require('./routes/movieRoutes');
const seriesRoutes = require('./routes/seriesRoutes');
const interactionRoutes = require('./routes/interactionRoutes');
const adminRoutes = require('./routes/adminRoutes');

const app = express();

app.use(helmet());
app.use(cors());
app.use(morgan('dev'));

// --- JAVÍTÁS ITT: MÉRET LIMIT NÖVELÉSE ---
// Az alapbeállítás (100kb) helyett 10MB-ot engedélyezünk a képek miatt
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));
// ------------------------------------------

// Végpontok használata
app.use('/api/auth', authRoutes);
app.use('/api/filmek', movieRoutes);
app.use('/api/sorozatok', seriesRoutes);
app.use('/api/interactions', interactionRoutes);
app.use('/api/admin', adminRoutes);

app.use((req, res) => {
    res.status(404).json({ message: 'Az útvonal nem található' });
});

module.exports = app;