import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import MovieRow from './components/MovieRow';
import ModalManager from './components/ModalManager';
import AuthModal from './components/AuthModal';
import Toast from './components/Toast';
import ConfirmModal from './components/ConfirmModal';
import Footer from './components/Footer';
import ProfilSzerkeszto from './components/ProfilSzerkeszto';
import ProfilDropdown from './components/ProfilDropdown';
import { moviesData, seriesData } from './data';
import './App.css';

function App() {
  // --- STATEK (Állapotok) ---
  
  // Adatok
  const featuredMovies = moviesData.slice(0, 5); // Az első 5 film a sliderbe
  const [currentSlide, setCurrentSlide] = useState(0);
  const [scrolled, setScrolled] = useState(false);

  // Felhasználó és Auth
  const [user, setUser] = useState(null); // null = nincs belépve
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  // Értesítések
  const [toast, setToast] = useState(null); // { message: '', type: 'success' | 'info' }

  // Modals (Ablakok)
  const [trailerModal, setTrailerModal] = useState({ isOpen: false, videoId: '', title: '' });
  const [streamingModal, setStreamingModal] = useState({ isOpen: false, movie: null });
  const [infoModal, setInfoModal] = useState({ isOpen: false, movie: null });

  // --- USE EFFECTS ---

  // Automatikus lapozás (8 másodperc)
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredMovies.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [featuredMovies.length]);

  // Navbar színezés görgetésre
  useEffect(() => {
      window.onscroll = () => setScrolled(window.pageYOffset > 50);
      return () => (window.onscroll = null);
  }, []);

  // --- FÜGGVÉNYEK ---

  // Értesítés megjelenítése
  const showNotification = (message, type = 'success') => {
    setToast({ message, type });
  };

  // Bejelentkezés kezelése
  const handleLogin = (userData) => {
    const userWithFavorites = {
      ...userData,
      favoriteCategories: userData.favoriteCategories || []
    };
    setUser(userWithFavorites);
    showNotification(`Sikeres belépés! Üdv, ${userData.name}!`, 'success');
  };

  // Profil frissítése
  const handleUpdateProfile = (updatedData) => {
    setUser(prev => ({
      ...prev,
      ...updatedData
    }));
    showNotification('Profil sikeresen frissítve!', 'success');
  };

  // Kijelentkezés folyamata
  const initiateLogout = () => {
    setShowLogoutConfirm(true); // Először megerősítést kérünk
  };

  const confirmLogout = () => {
    setUser(null);
    setShowLogoutConfirm(false);
    showNotification('Sikeresen kijelentkeztél.', 'info');
  };

  // Modal megnyitók/bezárók
  const openTrailer = (videoId, title) => setTrailerModal({ isOpen: true, videoId, title });
  const closeTrailer = () => setTrailerModal({ ...trailerModal, isOpen: false });

  const openStreaming = (movie) => {
    setInfoModal({ ...infoModal, isOpen: false }); // Ha nyitva volt az info, bezárjuk
    setStreamingModal({ isOpen: true, movie });
  };
  const closeStreaming = () => setStreamingModal({ ...streamingModal, isOpen: false });

  const openInfo = (movie) => setInfoModal({ isOpen: true, movie });
  const closeInfo = () => setInfoModal({ ...infoModal, isOpen: false });

  // Slider lapozás
  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % featuredMovies.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + featuredMovies.length) % featuredMovies.length);

  return (
    <div className="page">
      {/* 1. NAVBAR */}
      <Navbar 
        scrolled={scrolled} 
        user={user} 
        onOpenAuth={() => setAuthModalOpen(true)}
        onLogout={initiateLogout}
        onUpdateProfile={handleUpdateProfile}
      />

      <main>
        {/* 2. HERO SLIDER */}
        <section className="featured-section">
            {/* Bal nyíl */}
            <button className="slider-arrow left" onClick={prevSlide}>
                <i className="fas fa-chevron-left"></i>
            </button>

            <div className="slider-container">
                {featuredMovies.map((movie, index) => (
                    <div 
                        key={movie.id} 
                        className={`movie-slide-split ${index === currentSlide ? 'active' : ''}`}
                        style={{ backgroundImage: `url(${movie.poster})` }}
                    >
                        <div className="slide-backdrop-blur"></div>

                        <div className="split-content-wrapper">
                            
                            {/* BAL OLDAL: SZÖVEG */}
                            <div className="slide-left-info">
                                <h1>{movie.title}</h1>
                                <div className="movie-meta-tags">
                                    <span className="rating-tag"><i className="fas fa-star"></i> {movie.rating}</span>
                                    <span className="year-tag">{movie.year}</span>
                                    <span className="genre-tag">{movie.genre}</span>
                                </div>
                                
                                <div className="description-block">
                                    <p className="plot">{movie.description}</p>
                                    <div className="credits">
                                        <p><strong>Rendező:</strong> {movie.director}</p>
                                        <p><strong>Szereplők:</strong> {movie.actors}</p>
                                    </div>
                                </div>
                                
                                <div className="info-buttons">
                                    {/* Slider "Megnézem" -> STREAMING ablak */}
                                    <button className="btn-watch" onClick={() => openStreaming(movie)}>
                                        <i className="fas fa-play"></i> Megnézem
                                    </button>
                                </div>
                            </div>

                            {/* JOBB OLDAL: KÉP */}
                            <div className="slide-right-image-frame">
                                <img src={movie.poster} alt={movie.title} />
                                {/* Slider Kép kattintás -> TRAILER */}
                                <button className="play-btn-on-image" onClick={() => openTrailer(movie.trailerId, movie.title)}>
                                    <i className="fas fa-play"></i>
                                </button>
                            </div>

                        </div>
                    </div>
                ))}
            </div>

            {/* Jobb nyíl */}
            <button className="slider-arrow right" onClick={nextSlide}>
                <i className="fas fa-chevron-right"></i>
            </button>
        </section>

        {/* 3. LISTÁK (Filmek és Sorozatok) */}
        <div className="content-container">
            <MovieRow 
                title="Népszerű filmek" 
                items={moviesData} 
                onOpenTrailer={(trailerId, title) => openTrailer(trailerId, title)} // Kép -> Trailer
                onOpenStreaming={(movie) => openStreaming(movie)} // Megnézem -> Streaming
                onOpenInfo={(movie) => openInfo(movie)} // Részletek -> Info
            />
            <MovieRow 
                title="Sorozatok" 
                items={seriesData} 
                isSeries={true} 
                onOpenTrailer={(trailerId, title) => openTrailer(trailerId, title)} // Kép -> Trailer
                onOpenStreaming={(movie) => openStreaming(movie)} // Megnézem -> Streaming
                onOpenInfo={(movie) => openInfo(movie)} // Részletek -> Info
            />
        </div>
      </main>

      {/* 4. FOOTER */}
      <Footer />

      {/* --- MODALOK --- */}
      
      {/* Videó, Infó, Streaming kezelő */}
      <ModalManager 
        trailerModal={trailerModal} closeTrailer={closeTrailer}
        infoModal={infoModal} closeInfo={closeInfo}
        streamingModal={streamingModal} closeStreaming={closeStreaming}
        openStreaming={openStreaming}
      />
      
      {/* Bejelentkezés / Regisztráció */}
      {authModalOpen && <AuthModal onClose={() => setAuthModalOpen(false)} onLogin={handleLogin} />}

      {/* Kijelentkezés megerősítése */}
      <ConfirmModal 
        isOpen={showLogoutConfirm} 
        onClose={() => setShowLogoutConfirm(false)} 
        onConfirm={confirmLogout}
        title="Kijelentkezés"
        message="Biztosan ki szeretnél lépni a fiókodból?"
      />

      {/* Értesítések (Jobb felső sarok) */}
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}

export default App;