import React, { useState } from 'react';
import logoImg from '../logo.png'; 
import ProfilDropdown from './ProfilDropdown';

export default function Navbar({ scrolled, user, onOpenAuth, onLogout, onUpdateProfile }) {
  const [searchActive, setSearchActive] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  return (
    <nav className={scrolled ? 'scrolled' : ''}>
      <div className="nav-container">
        
        {/* BAL OLDAL */}
        <div className="nav-left">
            <a href="/" className="logo-link">
                <div className="logo">
                    <img src={logoImg} alt="MoziPont Logo" />
                </div>
            </a>
            <ul className="nav-links">
                <li><a href="/">Kezdőlap</a></li>
                <li><a href="#series">Sorozatok</a></li>
                <li><a href="#movies">Filmek</a></li>
                <li><a href="#list">Saját lista</a></li>
            </ul>
        </div>

        {/* JOBB OLDAL */}
        <div className="nav-right">
            <div className={`search-box ${searchActive ? 'active' : ''}`}>
                <button className="search-btn" onClick={() => setSearchActive(!searchActive)}>
                    <i className="fas fa-search"></i>
                </button>
                <input 
                    type="text" 
                    placeholder="Címek, emberek, műfajok..." 
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                />
            </div>
            
            {user ? (
                // CSAK EZT HASZNÁLJUK MOST:
                <ProfilDropdown user={user} onLogout={onLogout} />
            ) : (
                <button className="btn-login" onClick={onOpenAuth}>
                    Bejelentkezés
                </button>
            )}
        </div>
      </div>
    </nav>
  );
}