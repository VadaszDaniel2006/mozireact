import React, { useState, useEffect, useRef } from 'react';

const ProfilDropdown = ({ user, onLogout, onUpdateProfile }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showProfileEditor, setShowProfileEditor] = useState(false);
  const dropdownRef = useRef(null);

  // Kattintás kívülre bezárás
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSaveProfile = (updatedData) => {
    if (onUpdateProfile) {
      onUpdateProfile(updatedData);
    }
  };

  return (
    <>
      <div className="profil-container" ref={dropdownRef}>
        {/* Profil gomb */}
        <button 
          className="profil-btn" 
          onClick={() => setIsOpen(!isOpen)}
        >
          <div className="profil-avatar-small">
            <img src={user?.avatar || 'https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png'} 
                 alt={user?.username || user?.name} />
          </div>
          <span className="profil-name">
            {user?.username || user?.name || 'Felhasználó'}
          </span>
          <i className={`fas fa-chevron-${isOpen ? 'up' : 'down'}`}></i>
        </button>

        {/* Dropdown menü */}
        {isOpen && (
          <div className="profil-menu">
            <div className="profil-header">
              <div className="profil-avatar-large">
                <img src={user?.avatar || 'https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png'} 
                     alt={user?.username || user?.name} />
              </div>
              <div className="profil-info">
                <h4>{user?.username || user?.name}</h4>
                <p>{user?.email}</p>
                {user?.favoriteCategories && user.favoriteCategories.length > 0 && (
                  <div className="profil-tags">
                    {user.favoriteCategories.slice(0, 2).map((cat, index) => (
                      <span key={index} className="profil-tag">{cat}</span>
                    ))}
                    {user.favoriteCategories.length > 2 && (
                      <span className="profil-tag">+{user.favoriteCategories.length - 2}</span>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="profil-menu-items">
              <button 
                className="menu-item" 
                onClick={() => {
                  setIsOpen(false);
                  setShowProfileEditor(true);
                }}
              >
                <i className="fas fa-edit"></i>
                <span>Profil szerkesztése</span>
              </button>
              
              <button className="menu-item">
                <i className="fas fa-heart"></i>
                <span>Kedvenceim</span>
                {user?.favoriteCategories && user.favoriteCategories.length > 0 && (
                  <span className="menu-badge">{user.favoriteCategories.length}</span>
                )}
              </button>
              
              <button className="menu-item">
                <i className="fas fa-history"></i>
                <span>Megnézési előzmények</span>
              </button>
              
              <button className="menu-item">
                <i className="fas fa-list"></i>
                <span>Saját listáim</span>
              </button>
              
              <div className="menu-divider"></div>
              
              <button className="menu-item">
                <i className="fas fa-cog"></i>
                <span>Beállítások</span>
              </button>
              
              <button className="menu-item">
                <i className="fas fa-question-circle"></i>
                <span>Súgó</span>
              </button>
              
              <div className="menu-divider"></div>
              
              <button className="menu-item logout" onClick={onLogout}>
                <i className="fas fa-sign-out-alt"></i>
                <span>Kijelentkezés</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Profil szerkesztő modal - JAVÍTOTT CSS CLASSOKKAL */}
      {showProfileEditor && (
        <ProfilSzerkesztoModal 
          user={user}
          onClose={() => setShowProfileEditor(false)}
          onSave={handleSaveProfile}
        />
      )}
    </>
  );
};

// Profil szerkesztő modal komponens
const ProfilSzerkesztoModal = ({ user, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    email: '',
    avatar: '',
    favoriteCategories: []
  });

  // Kategóriák listája
  const categories = [
    { id: 'action', name: 'Akció', icon: '💥' },
    { id: 'comedy', name: 'Vígjáték', icon: '😂' },
    { id: 'drama', name: 'Dráma', icon: '🎭' },
    { id: 'horror', name: 'Horror', icon: '👻' },
    { id: 'sci-fi', name: 'Sci-Fi', icon: '🚀' },
    { id: 'romance', name: 'Romantikus', icon: '❤️' },
    { id: 'thriller', name: 'Thriller', icon: '🔪' },
    { id: 'fantasy', name: 'Fantasy', icon: '🐉' },
    { id: 'animation', name: 'Animáció', icon: '🎨' },
    { id: 'documentary', name: 'Dokumentum', icon: '🎥' },
    { id: 'family', name: 'Családi', icon: '👨‍👩‍👧‍👦' },
    { id: 'adventure', name: 'Kaland', icon: '🗺️' }
  ];

  // Betöltjük a felhasználó adatait
  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || '',
        username: user.username || '',
        email: user.email || '',
        avatar: user.avatar || 'https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png',
        favoriteCategories: user.favoriteCategories || []
      });
    }
  }, [user]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCategoryToggle = (categoryId) => {
    setFormData(prev => {
      const currentCategories = [...prev.favoriteCategories];
      const index = currentCategories.indexOf(categoryId);
      
      if (index > -1) {
        // Eltávolítjuk
        currentCategories.splice(index, 1);
      } else {
        // Hozzáadjuk (max 5)
        if (currentCategories.length < 5) {
          currentCategories.push(categoryId);
        } else {
          alert('Maximum 5 kedvenc kategóriát választhatsz!');
        }
      }
      
      return { ...prev, favoriteCategories: currentCategories };
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (onSave) {
      onSave(formData);
    }
    onClose();
  };

  return (
    <div className="profile-modal-overlay" onClick={onClose}>
      <div className="profile-modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="profile-modal-header">
          <h3>📝 Profil szerkesztése</h3>
          <button className="profile-close-modal" onClick={onClose}>
            <i className="fas fa-times"></i>
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="profile-modal-body">
            
            {/* Profil kép */}
            <div className="avatar-section">
              <div className="avatar-preview">
                <img src={formData.avatar} alt="Profil kép" />
                <button 
                  type="button" 
                  className="avatar-change-btn"
                  onClick={() => {
                    const newAvatar = prompt('Adj meg egy új profilkép URL-t:', formData.avatar);
                    if (newAvatar) {
                      setFormData(prev => ({ ...prev, avatar: newAvatar }));
                    }
                  }}
                >
                  <i className="fas fa-camera"></i> Kép cseréje
                </button>
              </div>
            </div>

            {/* Alapadatok */}
            <div className="form-section">
              <h4>Alapadatok</h4>
              
              <div className="input-group">
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder=" "
                  required
                />
                <label>Teljes név</label>
              </div>

              <div className="input-group">
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  placeholder=" "
                  required
                />
                <label>Felhasználónév</label>
              </div>

              <div className="input-group">
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder=" "
                  required
                />
                <label>Email cím</label>
              </div>
            </div>

            {/* Kedvenc kategóriák */}
            <div className="form-section">
              <h4>🎯 Kedvenc kategóriák</h4>
              <p className="section-subtitle">
                Válaszd ki a kedvenc filmes kategóriáidat! (Maximum 5)
              </p>
              
              <div className="categories-container">
                <div className="categories-grid">
                  {categories.map(category => (
                    <div 
                      key={category.id}
                      className={`category-item ${formData.favoriteCategories.includes(category.id) ? 'selected' : ''}`}
                      onClick={() => handleCategoryToggle(category.id)}
                    >
                      <span className="category-icon">{category.icon}</span>
                      <span className="category-name">{category.name}</span>
                      {formData.favoriteCategories.includes(category.id) && (
                        <span className="category-check">✓</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="selected-categories">
                <strong>Kiválasztott kategóriák:</strong>
                {formData.favoriteCategories.length > 0 ? (
                  <div className="selected-tags">
                    {formData.favoriteCategories.map(catId => {
                      const cat = categories.find(c => c.id === catId);
                      return (
                        <span key={catId} className="category-tag">
                          {cat.icon} {cat.name}
                        </span>
                      );
                    })}
                  </div>
                ) : (
                  <p className="no-selection">Még nem választottál ki kategóriát.</p>
                )}
                <p className="selection-count">
                  {formData.favoriteCategories.length} / 5 kategória kiválasztva
                </p>
              </div>
            </div>

            {/* Jelszó változtatás */}
            <div className="form-section">
              <h4>🔐 Jelszó változtatás</h4>
              <div className="input-group">
                <input
                  type="password"
                  placeholder=" "
                  name="currentPassword"
                  onChange={handleInputChange}
                />
                <label>Jelenlegi jelszó</label>
              </div>
              
              <div className="input-group">
                <input
                  type="password"
                  placeholder=" "
                  name="newPassword"
                  onChange={handleInputChange}
                />
                <label>Új jelszó</label>
              </div>
              
              <div className="input-group">
                <input
                  type="password"
                  placeholder=" "
                  name="confirmPassword"
                  onChange={handleInputChange}
                />
                <label>Új jelszó megerősítése</label>
              </div>
            </div>

            {/* Gombok */}
            <div className="modal-actions">
              <button 
                type="button" 
                className="btn-cancel"
                onClick={onClose}
              >
                Mégse
              </button>
              <button 
                type="submit" 
                className="btn-save"
              >
                <i className="fas fa-save"></i> Változások mentése
              </button>
            </div>

          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfilDropdown;