import { platformsInfo } from '../data';

export default function ModalManager({ 
  trailerModal, closeTrailer, 
  infoModal, closeInfo, openStreaming,
  streamingModal, closeStreaming 
}) {
  return (
    <>
      {/* 1. TRAILER MODAL */}
      {trailerModal.isOpen && (
        <div className="modal active" onClick={closeTrailer}>
          <div className="modal-content modal-lg" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{trailerModal.title} - Előzetes</h3>
              <button className="close-modal" onClick={closeTrailer}><i className="fas fa-times"></i></button>
            </div>
            <div className="video-container">
              <iframe 
                width="100%" height="500" 
                src={`https://www.youtube.com/embed/${trailerModal.videoId}?autoplay=1`} 
                title="Trailer" frameBorder="0" allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      )}

      {/* 2. INFO MODAL */}
      {infoModal.isOpen && infoModal.movie && (
        <div className="modal active" onClick={closeInfo}>
          <div className="modal-content modal-md" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Részletek</h3>
              <button className="close-modal" onClick={closeInfo}><i className="fas fa-times"></i></button>
            </div>
            
            <div className="info-layout">
              <div className="info-poster">
                <img src={infoModal.movie.poster} alt={infoModal.movie.title} />
              </div>
              
              <div className="info-text">
                <h2>{infoModal.movie.title}</h2>
                <div className="info-meta">
                    <span>{infoModal.movie.year}</span>
                    <span>{infoModal.movie.rating} <i className="fas fa-star" style={{color:'#f5c518'}}></i></span>
                    <span>{infoModal.movie.genre}</span>
                </div>
                
                <p className="info-desc">{infoModal.movie.description}</p>
                
                <div className="info-credits">
                    <p><strong>Rendező:</strong> {infoModal.movie.director}</p>
                    <p><strong>Szereplők:</strong> {infoModal.movie.actors}</p>
                </div>

                <div className="info-actions">
                    {/* ITT KAPJA MEG AZ ÚJ STÍLUST */}
                    <button className="btn-modal-action" onClick={() => openStreaming(infoModal.movie)}>
                        <i className="fas fa-play"></i> Megnézem most
                    </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* 3. STREAMING MODAL */}
      {streamingModal.isOpen && streamingModal.movie && (
        <div className="modal active" onClick={closeStreaming}>
          <div className="modal-content modal-sm" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Hol nézheted meg?</h3>
              <button className="close-modal" onClick={closeStreaming}><i className="fas fa-times"></i></button>
            </div>
            <div className="streaming-services">
              {streamingModal.movie.platforms && streamingModal.movie.platforms.map(platform => (
                <div 
                    key={platform} 
                    className="streaming-service" 
                    onClick={() => window.open(platformsInfo[platform].url, '_blank')}
                >
                   <div className="service-logo">
                        <img src={platformsInfo[platform].logo} alt={platformsInfo[platform].name}/>
                   </div>
                   <span>{platformsInfo[platform].name}</span>
                   <i className="fas fa-external-link-alt" style={{marginLeft:'auto', color:'#888'}}></i>
                </div>
              ))}
              {(!streamingModal.movie.platforms) && <p style={{padding:'20px', color:'#ccc'}}>Nincs elérhető streaming adat.</p>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}