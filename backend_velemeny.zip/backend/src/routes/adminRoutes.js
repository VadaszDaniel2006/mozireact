const express = require('express');
const router = express.Router();
const { protect, admin } = require('../middleware/authMiddleware');
const adminController = require('../controllers/adminController');

// Listázás
router.get('/users', protect, admin, adminController.getAllUsers);

// Törlés
router.delete('/users/:id', protect, admin, adminController.deleteUser);

// --- ÚJ: Szerkesztés (Email/Jelszó/Rang) ---
router.put('/users/:id', protect, admin, adminController.updateUser);

module.exports = router;