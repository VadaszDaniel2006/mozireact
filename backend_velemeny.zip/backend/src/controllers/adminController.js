const db = require('../config/db');
const bcrypt = require('bcryptjs'); // Kell a jelszó titkosításhoz!

// Összes felhasználó listázása
exports.getAllUsers = async (req, res) => {
    try {
        const [users] = await db.query('SELECT id, nev, username, email, role, regisztracio_datum FROM users');
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: 'Hiba a felhasználók lekérésekor' });
    }
};

// Felhasználó törlése
exports.deleteUser = async (req, res) => {
    const id = req.params.id;
    try {
        await db.query('DELETE FROM users WHERE id = ?', [id]);
        res.json({ message: 'Felhasználó sikeresen törölve.' });
    } catch (error) {
        res.status(500).json({ message: 'Hiba a törléskor' });
    }
};

// --- ÚJ: Felhasználó szerkesztése (Email, Rang, Jelszó) ---
exports.updateUser = async (req, res) => {
    const id = req.params.id;
    const { email, password, role } = req.body;

    try {
        // 1. Megnézzük, hogy az új email cím foglalt-e MÁS által
        // (A "id != ?" azért kell, hogy saját magának ne jelezzen hibát, ha nem változtat emailt)
        const [existing] = await db.query('SELECT * FROM users WHERE email = ? AND id != ?', [email, id]);
        
        if (existing.length > 0) {
            return res.status(400).json({ message: "Ez az email cím már foglalt!" });
        }

        // 2. Frissítés
        let sql;
        let params;

        if (password && password.trim() !== "") {
            // HA VAN új jelszó -> Titkosítjuk és mentjük azt is
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(password, salt);
            
            sql = 'UPDATE users SET email = ?, role = ?, password_hash = ? WHERE id = ?';
            params = [email, role, hashedPassword, id];
        } else {
            // HA NINCS új jelszó -> Csak emailt és rangot mentünk
            sql = 'UPDATE users SET email = ?, role = ? WHERE id = ?';
            params = [email, role, id];
        }

        await db.query(sql, params);

        res.json({ message: "Felhasználó sikeresen frissítve!", user: { id, email, role } });

    } catch (error) {
        console.error("Update error:", error);
        res.status(500).json({ message: 'Hiba a frissítéskor' });
    }
};